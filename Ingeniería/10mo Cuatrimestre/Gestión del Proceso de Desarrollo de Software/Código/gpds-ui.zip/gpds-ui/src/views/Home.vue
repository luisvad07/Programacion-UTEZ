<!-- src/views/Home.vue -->
<template>
    <div>
      <h1>Home</h1>
      <p>Bienvenido a la página de inicio.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'HomePage'
  }
  </script>
  