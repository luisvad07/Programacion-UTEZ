package mx.edu.utez.gpdsautos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpdsAutosApplicationTests {

    @Test
    void contextLoads() {
    }

}
