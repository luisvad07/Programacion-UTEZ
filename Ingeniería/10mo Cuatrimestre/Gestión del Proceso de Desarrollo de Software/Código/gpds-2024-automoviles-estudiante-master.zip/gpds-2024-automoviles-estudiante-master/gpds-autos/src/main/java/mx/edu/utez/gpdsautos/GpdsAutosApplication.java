package mx.edu.utez.gpdsautos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GpdsAutosApplication {

    public static void main(String[] args) {
        SpringApplication.run(GpdsAutosApplication.class, args);
    }

}
