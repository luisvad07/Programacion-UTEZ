package mx.edu.utez.warehousemasterapi.dtos.auth;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import mx.edu.utez.warehousemasterapi.entities.users.Users;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class UserTokenDto {
    @NotBlank
    private String token;
    @NotNull
    private Users user;
}
