package mx.edu.utez.warehousemasterapi.services.racks;

import mx.edu.utez.warehousemasterapi.entities.racks.Racks;
import mx.edu.utez.warehousemasterapi.entities.racks.RacksRepository;
import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.entities.users.UsersRepository;
import mx.edu.utez.warehousemasterapi.entities.warehouses.Warehouses;
import mx.edu.utez.warehousemasterapi.utils.CurrentUserDetails;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class RacksServices {
    private final RacksRepository racksRepository;
    private final CurrentUserDetails currentUserDetails;
    private final UsersRepository usersRepository;

    @Autowired
    public RacksServices(RacksRepository racksRepository, CurrentUserDetails currentUserDetails, UsersRepository usersRepository) {
        this.racksRepository = racksRepository;
        this.currentUserDetails = currentUserDetails;
        this.usersRepository = usersRepository;
    }


    @Transactional(readOnly = true)
    public Response<List<Racks>> getAllRacks() {
        List<Racks> racks;
        Set<String> roles = currentUserDetails.getCurrentUserAuthorities();
        if (roles.contains("ADMIN")) {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            Warehouses warehouse = user.getWarehouse();
            racks = racksRepository.findAllByWarehouseUidOrderByLastModifiedDesc(warehouse.getUid());
        } else {
            racks = racksRepository.findAllByActiveNotNullOrderByLastModifiedDesc();
        }

        return new Response<>(racks, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<List<Racks>> getAllRacksByActive(Boolean active) {
        List<Racks> racks;
        Set<String> roles = currentUserDetails.getCurrentUserAuthorities();
        if (roles.contains("ADMIN")) {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            Warehouses warehouse = user.getWarehouse();
            racks = racksRepository.findAllByActiveAndWarehouseUidOrderByLastModifiedDesc(active, warehouse.getUid());
        } else {
            racks = racksRepository.findAllByActiveOrderByLastModifiedDesc(active);
        }

        return new Response<>(racks, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<Racks> getRackById(String id) {
        Racks rack = racksRepository.findByUidAndActive(id, true);
        return new Response<>(rack, false, 200, "ok!");
    }

    @Transactional
    public Response<Racks> saveRack(Racks rack) {
        Set<String> roles = currentUserDetails.getCurrentUserAuthorities();
        if (roles.contains("ADMIN")) {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            Warehouses warehouse = user.getWarehouse();
            rack.setWarehouse(warehouse);
        }
        rack.setActive(true);
        rack.setLastModified(new Timestamp(System.currentTimeMillis()));
        Racks rackSaved = racksRepository.save(rack);
        return new Response<>(rackSaved, false, 200, "ok!");
    }

    @Transactional
    public Response<Racks> updateRack(Racks rack) {
        rack.setLastModified(new Timestamp(System.currentTimeMillis()));
        Racks rackUpdated = racksRepository.save(rack);
        return new Response<>(rackUpdated, false, 200, "ok!");
    }

    @Transactional
    public Response<Racks> deleteRack(String id) {
        Optional<Racks> rack = racksRepository.findById(id);
        if (rack.isPresent()) {
            rack.get().setLastModified(new Timestamp(System.currentTimeMillis()));
            rack.get().setActive(!rack.get().getActive());
            Racks rackDeleted = racksRepository.save(rack.get());
            return new Response<>(rackDeleted, false, 200, "ok!");
        }
        return new Response<>(null, true, 404, "Not Found");
    }

    @Transactional(readOnly = true)
    public Response<List<Racks>> getRacksByWarehouse(String warehouseId) {
        List<Racks> racks = racksRepository.findByWarehouseUid(warehouseId);
        return new Response<>(racks, false, 200, "ok!");
    }


}

