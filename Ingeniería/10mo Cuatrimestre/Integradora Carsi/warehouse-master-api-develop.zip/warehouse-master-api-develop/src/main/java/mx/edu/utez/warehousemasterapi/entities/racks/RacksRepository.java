package mx.edu.utez.warehousemasterapi.entities.racks;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RacksRepository extends JpaRepository<Racks, String> {
    List<Racks> findAllByActiveOrderByLastModifiedDesc(Boolean active);
    List<Racks> findAllByActiveNotNullOrderByLastModifiedDesc();
    List<Racks> findAllByActiveAndWarehouseUidOrderByLastModifiedDesc(Boolean active, String warehouseUid);
    List<Racks> findAllByWarehouseUidOrderByLastModifiedDesc( String warehouseUid);
    List<Racks> findByWarehouseUid(String warehouseId);
    Racks findByUidAndActive(String uid, Boolean active);
}
