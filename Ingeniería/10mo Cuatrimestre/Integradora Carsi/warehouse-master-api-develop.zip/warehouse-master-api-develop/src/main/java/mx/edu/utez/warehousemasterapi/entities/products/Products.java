package mx.edu.utez.warehousemasterapi.entities.products;

import java.sql.Timestamp;
import java.util.List;

import mx.edu.utez.warehousemasterapi.entities.categories.Categories;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.warehousemasterapi.entities.movements.Movements;
import mx.edu.utez.warehousemasterapi.entities.racks.Racks;
import mx.edu.utez.warehousemasterapi.entities.suppliers.Suppliers;
import org.springframework.data.annotation.Transient;

@Entity
@Table(name = "products")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Products {
    @Id
    @UuidGenerator
    @Column(name = "uid")
    private String uid;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "price", columnDefinition = "DECIMAL(10, 2)")
    private Double price;

    @ManyToOne
    @JoinColumn(name = "supplier_id")
    private Suppliers supplier;

    @ManyToOne
    @JoinColumn(name = "uid_category")
    private Categories category;

    @ManyToOne
    @JoinColumn(name = "rack_id")
    private Racks rack;

    @Column(name = "floor_number")
    private Integer floorNumber;

    @Column(name = "stock", nullable = false)
    private Integer stock;

    @Transient
    private String qrCode;

    @Column(name = "expiration_date", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp expirationDate;

    @Column(name = "active", columnDefinition = "BOOLEAN DEFAULT TRUE")
    private Boolean active;
    @Column(name = "last_modified", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp lastModified;

}
