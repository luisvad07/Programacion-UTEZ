package mx.edu.utez.warehousemasterapi.controllers.categories;

import mx.edu.utez.warehousemasterapi.entities.categories.Categories;
import mx.edu.utez.warehousemasterapi.services.categories.CategoriesServices;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("${apiPrefix}/categories")
@CrossOrigin(value = {"*"})
public class CategoriesController {
    private final CategoriesServices categoriesService;

    @Autowired
    public CategoriesController(CategoriesServices categoriesService) {
        this.categoriesService = categoriesService;
    }

    @GetMapping("/")
    public ResponseEntity<Response<List<Categories>>> getAllCategories() {
        Response<List<Categories>> response = categoriesService.getAllCategories();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/active/{active}")
    public ResponseEntity<Response<List<Categories>>> getAllCategoriesByActive(@PathVariable Boolean active) {
        Response<List<Categories>> response = categoriesService.getAllCategoriesByActive(active);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Response<Categories>> getCategoryById(@PathVariable String id) {
        Response<Categories> response = categoriesService.getCategoryById(id);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PostMapping("/")
    public ResponseEntity<Response<Categories>> saveCategory(@RequestBody Categories category) {
        Response<Categories> response = categoriesService.saveCategory(category);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/")
    public ResponseEntity<Response<Categories>> updateCategory(@RequestBody Categories category) {
        Response<Categories> response = categoriesService.updateCategory(category);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Response<Categories>> deleteCategory(@PathVariable String id) {
        Response<Categories> response = categoriesService.deleteCategory(id);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }
}