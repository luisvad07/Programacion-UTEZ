package mx.edu.utez.warehousemasterapi.entities.racks;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.warehousemasterapi.entities.products.Products;
import mx.edu.utez.warehousemasterapi.entities.warehouses.Warehouses;

@Entity
@Table(name = "racks")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Racks {
    @Id
    @UuidGenerator
    @Column(name = "uid")
    private String uid;

    @ManyToOne
    @JoinColumn(name = "warehouse_id", nullable = false)
    private Warehouses warehouse;
    
    @Column(name = "rack_number", nullable = false)
    private String rackNumber;

    @Column(name = "capacity", nullable = false)
    private Integer capacity;

    @Column(name = "description")
    private String description;

    @Column(name = "max_floor")
    private Integer maxFloor;

    @Column(name = "active", columnDefinition = "BOOLEAN DEFAULT TRUE")
    private Boolean active;
    @Column(name = "last_modified", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp lastModified;
}
