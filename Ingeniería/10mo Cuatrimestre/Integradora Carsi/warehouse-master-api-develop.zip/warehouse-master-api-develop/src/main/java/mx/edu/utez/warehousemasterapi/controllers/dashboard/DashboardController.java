package mx.edu.utez.warehousemasterapi.controllers.dashboard;

import mx.edu.utez.warehousemasterapi.entities.dashboard.Dashboard;
import mx.edu.utez.warehousemasterapi.services.dashboard.DashboardService;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${apiPrefix}/dashboard")
@CrossOrigin(value = {"*"})
public class DashboardController {
    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }


    @GetMapping("/")
    public ResponseEntity<Response<Dashboard>> getDashboard() {
        Response<Dashboard> response = dashboardService.getDashboard();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }
}
