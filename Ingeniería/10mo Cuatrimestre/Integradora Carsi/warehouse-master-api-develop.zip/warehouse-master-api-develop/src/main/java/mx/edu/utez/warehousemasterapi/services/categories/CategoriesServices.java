package mx.edu.utez.warehousemasterapi.services.categories;

import mx.edu.utez.warehousemasterapi.entities.categories.Categories;
import mx.edu.utez.warehousemasterapi.entities.categories.CategoriesRepository;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Service
public class CategoriesServices {
    private final CategoriesRepository categoriesRepository;

    @Autowired
    public CategoriesServices(CategoriesRepository categoriesRepository) {
        this.categoriesRepository = categoriesRepository;
    }

    @Transactional(readOnly = true)
    public Response<List<Categories>> getAllCategories() {
        List<Categories> categories = categoriesRepository.findAll();
        return new Response<>(categories, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<List<Categories>> getAllCategoriesByActive(Boolean active) {
        List<Categories> categories = categoriesRepository.findAllByActiveOrderByLastModifiedDesc(active);
        return new Response<>(categories, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<Categories> getCategoryById(String id) {
        Categories category = categoriesRepository.findByUidAndActive(id, true);
        return new Response<>(category, false, 200, "ok!");
    }

    @Transactional
    public Response<Categories> saveCategory(Categories category) {
        category.setActive(true);
        category.setLastModified(new Timestamp(System.currentTimeMillis()));
        Categories categorySaved = categoriesRepository.save(category);
        return new Response<>(categorySaved, false, 200, "ok!");
    }

    @Transactional
    public Response<Categories> updateCategory(Categories category) {
        Categories categoryUpdated = categoriesRepository.save(category);
        return new Response<>(categoryUpdated, false, 200, "ok!");
    }

    @Transactional
    public Response<Categories> deleteCategory(String id) {
        Optional<Categories> category = categoriesRepository.findById(id);
        if (category.isPresent()) {
            category.get().setActive(!category.get().getActive());
            category.get().setLastModified(new Timestamp(System.currentTimeMillis()));
            Categories categoryDeleted = categoriesRepository.save(category.get());
            return new Response<>(categoryDeleted, false, 200, "ok!");
        }
        return new Response<>(null, true, 404, "Not Found");
    }
}
