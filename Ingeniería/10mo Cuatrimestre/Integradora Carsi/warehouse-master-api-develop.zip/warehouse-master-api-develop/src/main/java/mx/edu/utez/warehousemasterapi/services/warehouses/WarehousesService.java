package mx.edu.utez.warehousemasterapi.services.warehouses;

import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.entities.users.UsersRepository;
import mx.edu.utez.warehousemasterapi.entities.warehouses.Warehouses;
import mx.edu.utez.warehousemasterapi.entities.warehouses.WarehousesRepository;
import mx.edu.utez.warehousemasterapi.utils.CurrentUserDetails;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class WarehousesService {
    private final WarehousesRepository warehousesRepository;
    private final CurrentUserDetails currentUserDetails;
    private final UsersRepository usersRepository;

    @Autowired
    public WarehousesService(WarehousesRepository warehousesRepository, CurrentUserDetails currentUserDetails, UsersRepository usersRepository) {
        this.warehousesRepository = warehousesRepository;
        this.currentUserDetails = currentUserDetails;
        this.usersRepository = usersRepository;
    }

    @Transactional(readOnly = true)
    public Response<List<Warehouses>> getAllWarehouses() {
        List<Warehouses> warehouses;
        Set<String> roles = currentUserDetails.getCurrentUserAuthorities();
        if (roles.contains("ADMIN")) {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            Warehouses warehouse = user.getWarehouse();
            warehouses = warehousesRepository.findAllByUidOrderByLastModifiedDesc(warehouse.getUid());
        } else {
            warehouses = warehousesRepository.findAllByActiveNotNullOrderByLastModified();
        }
        return new Response<>(warehouses, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<List<Warehouses>> getAllWarehousesByActive(Boolean active) {
        List<Warehouses> warehouses;
        Set<String> roles = currentUserDetails.getCurrentUserAuthorities();
        if (roles.contains("ADMIN")) {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            Warehouses warehouse = user.getWarehouse();
            warehouses = warehousesRepository.findAllByActiveAndUidOrderByLastModifiedDesc(active, warehouse.getUid());
        } else {
            warehouses = warehousesRepository.findAllByActiveOrderByLastModifiedDesc(active);
        }
        return new Response<>(warehouses, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<Warehouses> getWarehouseByName(String name) {
        Warehouses warehouse = warehousesRepository.findByNameAndActive(name, true);
        return new Response<>(warehouse, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<Warehouses> getWarehouseByUid(String uid) {
        Warehouses warehouse = warehousesRepository.findByUidAndActive(uid, true);
        return new Response<>(warehouse, false, 200, "ok!");
    }

    @Transactional(rollbackFor = {SQLException.class})
    public Response<Warehouses> createWarehouse(Warehouses warehouse) {
        warehouse.setActive(true);
        warehouse.setLastModified(Timestamp.valueOf(java.time.LocalDateTime.now()));
        return new Response<>(warehousesRepository.save(warehouse), false, 200, "ok!");
    }

    @Transactional(rollbackFor = {SQLException.class})
    public Response<Warehouses> updateWarehouse(Warehouses warehouse) {
        warehouse.setActive(true);
        warehouse.setLastModified(Timestamp.valueOf(java.time.LocalDateTime.now()));
        Optional<Warehouses> update = warehousesRepository.findById(warehouse.getUid());
        if (update.isPresent()) {
            return new Response<>(warehousesRepository.saveAndFlush(warehouse), false, 200, "Updated!");
        }
        return new Response<>(null, true, 404, "Not Found");
    }

    @Transactional
    public Response<Warehouses> deleteWarehouse(String uid) {
        Optional<Warehouses> warehouse = warehousesRepository.findById(uid);
        if (warehouse.isPresent()) {
            warehouse.get().setActive(!warehouse.get().getActive());
            warehouse.get().setLastModified(new Timestamp(System.currentTimeMillis()));
            Warehouses warehouseDeleted = warehousesRepository.save(warehouse.get());
            return new Response<>(warehouseDeleted, false, 200, "ok!");
        }
        return new Response<>(null, true, 404, "Not Found");
    }
}