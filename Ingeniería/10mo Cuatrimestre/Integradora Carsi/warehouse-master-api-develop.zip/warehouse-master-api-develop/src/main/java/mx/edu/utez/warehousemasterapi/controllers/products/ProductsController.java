package mx.edu.utez.warehousemasterapi.controllers.products;

import mx.edu.utez.warehousemasterapi.entities.products.Products;
import mx.edu.utez.warehousemasterapi.services.products.ProductsService;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("${apiPrefix}/products")
@CrossOrigin(value = {"*"})
public class ProductsController {
    private final ProductsService productsService;

    @Autowired
    public ProductsController(ProductsService productsService) {
        this.productsService = productsService;
    }

    @GetMapping("/")
    public ResponseEntity<Response<List<Products>>> getAllProducts() {
        Response<List<Products>> response = productsService.getAllProducts();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }
    @GetMapping("/active/{active}")
    public ResponseEntity<Response<List<Products>>> getAllProductsByActive(@PathVariable Boolean active) {
        Response<List<Products>> response = productsService.getAllProductsByActive(active);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Response<Products>> getProductById(@PathVariable String id) {
        Response<Products> response = productsService.getProductById(id);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PostMapping("/")
    public ResponseEntity<Response<Products>> saveProduct(@RequestBody Products product) {
        Response<Products> response = productsService.saveProduct(product);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/")
    public ResponseEntity<Response<Products>> updateProduct(@RequestBody Products product) {
        Response<Products> response = productsService.updateProduct(product);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Response<Products>> deleteProduct(@PathVariable String id) {
        Response<Products> response = productsService.deleteProduct(id);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }
}