package mx.edu.utez.warehousemasterapi.entities.users;

import mx.edu.utez.warehousemasterapi.enums.roles.Role;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsersRepository extends JpaRepository<Users, String> {
    List<Users> findAllByActiveOrderByLastModifiedDesc(Boolean active);

    Page<Users> findAllByActiveOrderByLastModifiedDesc(Boolean active, Pageable pageable);

    Users findByEmailAndActive(String email, Boolean active);

    List<Users> findAllByActiveAndRoleOrderByLastModifiedDesc(Boolean active, Role role);


    Optional<Users> findByEmail(String email);
    Users findByUidAndActive(String uid, Boolean active);

    Integer countByActive(Boolean active);
}