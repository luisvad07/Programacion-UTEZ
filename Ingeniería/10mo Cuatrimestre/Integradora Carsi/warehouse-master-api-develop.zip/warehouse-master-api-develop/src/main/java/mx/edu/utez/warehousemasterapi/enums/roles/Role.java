package mx.edu.utez.warehousemasterapi.enums.roles;

public enum Role {
    SUPER_ADMIN,
    ADMIN,
    WAREHOUSE_WORKER,
    CLIENT
}