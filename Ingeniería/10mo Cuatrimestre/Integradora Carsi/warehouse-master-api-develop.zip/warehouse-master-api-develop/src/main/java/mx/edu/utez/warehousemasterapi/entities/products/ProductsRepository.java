package mx.edu.utez.warehousemasterapi.entities.products;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductsRepository extends JpaRepository<Products, String> {
    List<Products> findAllByActiveOrderByLastModifiedDesc(Boolean active);
    List<Products> findAllByActiveAndRackWarehouseUidOrderByLastModifiedDesc(Boolean active, String warehouseUid);
    List<Products> findAllByRackWarehouseUidOrderByLastModifiedDesc(String warehouseUid);
    List<Products> findAllByActiveNotNullOrderByLastModifiedDesc();
    List<Products> findAllByActive(Boolean active);
    List<Products> findBySupplierUid(String supplierId);
    List<Products> findAllByActiveAndExpirationDateLessThan(Boolean active, Timestamp expirationDate);
    Products findByUidAndActive(String uid, Boolean active);
    Integer countByActive(Boolean active);
}

