package mx.edu.utez.warehousemasterapi.controllers.suppliers;

import mx.edu.utez.warehousemasterapi.entities.suppliers.Suppliers;
import mx.edu.utez.warehousemasterapi.services.suppliers.SuppliersServices;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("${apiPrefix}/suppliers")
@CrossOrigin(value = {"*"})
public class SuppliersController {
    private final SuppliersServices suppliersService;

    @Autowired
    public SuppliersController(SuppliersServices suppliersService) {
        this.suppliersService = suppliersService;
    }

    @GetMapping("/")
    public ResponseEntity<Response<List<Suppliers>>> getAllSuppliers() {
        Response<List<Suppliers>> response = suppliersService.getAllSuppliers();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/active/{active}")
    public ResponseEntity<Response<List<Suppliers>>> getAllSuppliersByActive(@PathVariable Boolean active) {
        Response<List<Suppliers>> response = suppliersService.getAllSuppliersByActive(active);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Response<Suppliers>> getSupplierById(@PathVariable String id) {
        Response<Suppliers> response = suppliersService.getSupplierById(id);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PostMapping("/")
    public ResponseEntity<Response<Suppliers>> saveSupplier(@RequestBody Suppliers supplier) {
        Response<Suppliers> response = suppliersService.saveSupplier(supplier);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/")
    public ResponseEntity<Response<Suppliers>> updateSupplier(@RequestBody Suppliers supplier) {
        Response<Suppliers> response = suppliersService.updateSupplier(supplier);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Response<Suppliers>> deleteSupplier(@PathVariable String id) {
        Response<Suppliers> response = suppliersService.deleteSupplier(id);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }
}