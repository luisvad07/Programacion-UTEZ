package mx.edu.utez.warehousemasterapi.entities.movementsHistory;

import jakarta.persistence.*;
import lombok.*;
import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.entities.movements.Movements;
import mx.edu.utez.warehousemasterapi.enums.status.Status;
import org.hibernate.annotations.UuidGenerator;

import java.sql.Timestamp;

@Entity
@Table(name = "movements_history")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MovementsHistory {
    @Id
    @UuidGenerator
    @Column(name = "uid")
    private String uid;
    @Column(columnDefinition = "ENUM('UNASSIGNED_ENTRY', 'UNASSIGNED_EXIT', 'UNASSIGNED_TRANSFER', 'UNASSIGNED_ADJUSTMENT','ASSIGNED_ENTRY', 'ASSIGNED_EXIT', 'ASSIGNED_TRANSFER', 'ASSIGNED_ADJUSTMENT','PENDING_ENTRY', 'PENDING_EXIT', 'PENDING_TRANSFER', 'PENDING_ADJUSTMENT', 'ENTRY', 'EXIT', 'TRANSFER', 'ADJUSTMENT','CANCELLED') NOT NULL DEFAULT 'EXIT'")
    @Enumerated(EnumType.STRING)
    private Status status;
    @Column(name = "last_modified", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp lastModified;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private Users user;
    @ManyToOne
    @JoinColumn(name = "movement_id")
    private Movements movement;
    @Column(name = "active", columnDefinition = "BOOLEAN DEFAULT TRUE")
    private Boolean active;
}