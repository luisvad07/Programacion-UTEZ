package mx.edu.utez.warehousemasterapi.entities.mfa;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MfaDeviceRepository extends JpaRepository<MfaDevice, Long> {
    Optional<MfaDevice> findByUser_Uid(String userId);
}