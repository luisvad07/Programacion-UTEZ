package mx.edu.utez.warehousemasterapi.dtos.auth;

import lombok.Data;

@Data
public class MfaVerificationDto {
    private String email;
    private String password;
    private String mfaCode;
}