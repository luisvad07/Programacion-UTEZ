package mx.edu.utez.warehousemasterapi.services.movements;

import mx.edu.utez.warehousemasterapi.entities.movementProducts.MovementsProducts;
import mx.edu.utez.warehousemasterapi.entities.movementProducts.MovementsProductsRepository;
import mx.edu.utez.warehousemasterapi.entities.movements.Movements;
import mx.edu.utez.warehousemasterapi.entities.movements.MovementsRepository;
import mx.edu.utez.warehousemasterapi.entities.movementsHistory.MovementsHistory;
import mx.edu.utez.warehousemasterapi.entities.movementsHistory.MovementsHistoryRepository;
import mx.edu.utez.warehousemasterapi.entities.products.Products;
import mx.edu.utez.warehousemasterapi.entities.products.ProductsRepository;
import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.entities.users.UsersRepository;
import mx.edu.utez.warehousemasterapi.entities.warehouses.Warehouses;
import mx.edu.utez.warehousemasterapi.enums.status.Status;
import mx.edu.utez.warehousemasterapi.utils.CurrentUserDetails;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
public class MovementsServices {
    private final MovementsRepository movementsRepository;
    private final CurrentUserDetails currentUserDetails;
    private final UsersRepository usersRepository;
    private final MovementsHistoryRepository movementsHistoryRepository;
    private final ProductsRepository productsRepository;
    private final MovementsProductsRepository movementsProductsRepository;


    @Autowired
    public MovementsServices(MovementsRepository movementsRepository, CurrentUserDetails currentUserDetails, UsersRepository usersRepository, MovementsHistoryRepository movementsHistoryRepository, ProductsRepository productsRepository, MovementsProductsRepository movementsProductsRepository) {
        this.movementsRepository = movementsRepository;
        this.currentUserDetails = currentUserDetails;
        this.usersRepository = usersRepository;
        this.movementsHistoryRepository = movementsHistoryRepository;
        this.productsRepository = productsRepository;
        this.movementsProductsRepository = movementsProductsRepository;
    }

    @Transactional(readOnly = true)
    public Response<List<Movements>> getAllMovements() {
        List<Movements> movements;
        Set<String> roles = currentUserDetails.getCurrentUserAuthorities();
        if (roles.contains("ADMIN")) {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            Warehouses warehouse = user.getWarehouse();
            movements = movementsRepository.findAllMovementsByProductsRackWharehouseUid(warehouse.getUid());
        } else if (roles.contains("WAREHOUSE_WORKER")) {
            movements = movementsRepository.findAllByAssignedUserEmail(currentUserDetails.getCurrentUserDetails().getUsername());
        } else if (roles.contains("CLIENT")) {
            movements = movementsRepository.findAllByUserEmailAndActive(currentUserDetails.getCurrentUserDetails().getUsername(), true);
        } else {
            movements = movementsRepository.findAllByActiveOrderByLastModifiedDesc(true);
        }
        return new Response<>(movements, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<Movements> getMovementById(String id) {
        Movements movement = movementsRepository.findByUidAndActive(id, true);
        return new Response<>(movement, false, 200, "ok!");
    }

    @Transactional
    public Response<Movements> saveMovement(Movements movement) {
        UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
        Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
        movement.setUser(user);
        movement.setActive(true);
        movement.setLastModified(new Timestamp(System.currentTimeMillis()));
        // set movement as unassigned
        if (movement.getStatus() != null && movement.getAssignedUser() == null) {
            String newStatus = "UNASSIGNED_" + movement.getStatus();
            movement.setStatus(Status.valueOf(newStatus));
        } else if (movement.getStatus() == null && movement.getAssignedUser() == null) {
            movement.setStatus(Status.UNASSIGNED_EXIT);
        } else {
            String newStatus = "ASSIGNED_" + movement.getStatus();
            movement.setStatus(Status.valueOf(newStatus));
        }
        Movements movementSaved = movementsRepository.save(movement);
        List<MovementsProducts> products = movement.getProducts();
        for (MovementsProducts product : products) {
            product.setMovement(movementSaved);
            movementsProductsRepository.save(product);
        }
        return new Response<>(movementSaved, false, 200, "ok!");
    }

    public void generateMovementsHistory(Movements movement) {
        UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
        Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
        MovementsHistory movementsHistory = new MovementsHistory();
        movementsHistory.setMovement(movement);
        movementsHistory.setLastModified(new Timestamp(System.currentTimeMillis()));
        movementsHistory.setStatus(movement.getStatus());
        movementsHistory.setUser(user);
        movementsHistoryRepository.save(movementsHistory);
    }

    @Transactional
    public Response<List<Movements>> saveCartOfMovements(List<Movements> movements) {
        List<Movements> movementsSaved = new ArrayList<>();
        for (Movements movement : movements) {
            movement.setStatus(Status.UNASSIGNED_EXIT);
            movement.setActive(true);
            movement.setLastModified(new Timestamp(System.currentTimeMillis()));
            Movements movementSaved = movementsRepository.save(movement);
            this.generateMovementsHistory(movementSaved);
            movementsSaved.add(movementSaved);
        }
        return new Response<>(movementsSaved, false, 200, "ok!");
    }

    @Transactional
    public Response<Movements> assignMovementToUser(String movementId, String userId) {
        Movements movement = movementsRepository.findByUidAndActive(movementId, true);
        movement.setAssignedUser(usersRepository.findByUidAndActive(userId, true));
        // WE GET STATUS IN STRING AND THEN PARSE TO ENUM
        String currentStatus = movement.getStatus().toString();

        if (currentStatus.contains("UNASSIGNED")) {
            //conseguimos lo que viene despues de UNASSIGNED_
            String status = currentStatus.substring(currentStatus.indexOf("_") + 1);
            //concatenamos ASSIGNED_ con el status
            movement.setStatus(Status.valueOf("ASSIGNED_" + status));
            movement.setLastModified(new Timestamp(System.currentTimeMillis()));
            Movements movementAssigned = movementsRepository.save(movement);
            this.generateMovementsHistory(movementAssigned);
            return new Response<>(movementAssigned, false, 200, "ok!");
        } else {
            return new Response<>(null, true, 400, "Movement already assigned");
        }

    }

    @Transactional
    public Response<Movements> cancelMovement(String movementId) {
        Movements movement = movementsRepository.findByUidAndActive(movementId, true);
        String currentStatus = movement.getStatus().toString();
        if (currentStatus.contains("PENDING")) {
            movement.setStatus(Status.CANCELLED);
            movement.setLastModified(new Timestamp(System.currentTimeMillis()));
            Movements movementCancelled = movementsRepository.save(movement);
            this.generateMovementsHistory(movementCancelled);
            return new Response<>(movementCancelled, false, 200, "ok!");
        } else {
            return new Response<>(null, true, 400, "Movement already approved or is unassigned");
        }
    }


    @Transactional
    public Response<Movements> approveMovement(String movementId) {
        Movements movement = movementsRepository.findByUidAndActive(movementId, true);
        String currentStatus = movement.getStatus().toString();
        if (currentStatus.contains("PENDING")) {
            String status = currentStatus.substring(currentStatus.indexOf("_") + 1);
            if (!validateStock(movement, status)) {
                return new Response<>(null, true, 400, "Insufficient stock for the movement");
            }
            adjustStock(movement, status);
            movement.setStatus(Status.valueOf(status));
            movement.setLastModified(new Timestamp(System.currentTimeMillis()));
            Movements movementApproved = movementsRepository.save(movement);
            this.generateMovementsHistory(movementApproved);
            return new Response<>(movementApproved, false, 200, "ok!");
        } else {
            return new Response<>(null, true, 400, "Movement already approved or is unassigned");
        }
    }




    private boolean validateStock(Movements movement, String status) {
        for (MovementsProducts movementProduct : movement.getProducts()) {
            int currentStock = productsRepository.findByUidAndActive(movementProduct.getProduct().getUid(), true).getStock();
            int movementQuantity = movementProduct.getQuantity();
            switch (status) {
                case "ENTRY":
                    continue;
                case "EXIT":
                case "TRANSFER":
                    if (currentStock < movementQuantity) {
                        return false;
                    }
                    break;
                case "ADJUSTMENT":
                    continue;
                default:
                    return false;
            }
        }
        return true;
    }

    private void adjustStock(Movements movement, String status) {
        for (MovementsProducts movementProduct : movement.getProducts()) {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            Products product = productsRepository.findByUidAndActive(movementProduct.getProduct().getUid(), true);
            int currentStock = product.getStock();
            int movementQuantity = movementProduct.getQuantity();
            switch (status) {
                case "ENTRY":
                    product.setStock(currentStock + movementQuantity);
                    break;
                case "EXIT":
                case "TRANSFER":
                    product.setStock(currentStock - movementQuantity);
                    if (status.equals("TRANSFER")) {
                        Products newProduct = new Products();
                        newProduct.setRack(movementProduct.getDestinationRack());
                        newProduct.setStock(movementQuantity);
                        newProduct.setUid(null);
                        newProduct.setActive(true);
                        newProduct.setCategory(product.getCategory());
                        newProduct.setName(product.getName());
                        newProduct.setDescription(product.getDescription());
                        newProduct.setPrice(product.getPrice());
                        newProduct.setFloorNumber(product.getFloorNumber());
                        newProduct.setSupplier(product.getSupplier());
                        newProduct.setExpirationDate(product.getExpirationDate());
                        newProduct.setLastModified(new Timestamp(System.currentTimeMillis()));
                        Products productSaved = productsRepository.save(newProduct);
                        Movements newMovement = new Movements();
                        newMovement.setProducts(List.of(movementProduct));
                        newMovement.setStatus(Status.ENTRY);
                        newMovement.setActive(true);
                        newMovement.setUser(user);
                        newMovement.setLastModified(new Timestamp(System.currentTimeMillis()));
                        newMovement.setObservations("Entrada de producto por transferencia de " + product.getName());
                        Movements movementSaved = movementsRepository.save(newMovement);
                        generateMovementsHistory(movementSaved);
                    }
                    break;
                case "ADJUSTMENT":
                    product.setStock(currentStock + movementQuantity); // Assuming adjustment can be positive or negative
                    break;
            }
            productsRepository.save(product);
        }
    }

    // unasinged movements

    @Transactional
    public Response<Movements> unassignMovement(String movementId) {
        Movements movement = movementsRepository.findByUidAndActive(movementId, true);
        String currentStatus = movement.getStatus().toString();
        if (currentStatus.contains("ASSIGNED")) {
            String status = currentStatus.substring(currentStatus.indexOf("_") + 1);
            movement.setStatus(Status.valueOf("UNASSIGNED_" + status));
            movement.setAssignedUser(null);
            movement.setLastModified(new Timestamp(System.currentTimeMillis()));
            Movements movementUnassigned = movementsRepository.save(movement);
            this.generateMovementsHistory(movementUnassigned);
            return new Response<>(movementUnassigned, false, 200, "ok!");
        } else {
            return new Response<>(null, true, 400, "Movement already unassigned");
        }
    }

    @Transactional
    public Response<Movements> updateMovement(Movements movement) {
        if (movement.getStatus() != null && !movement.getStatus().equals(Status.CANCELLED)) {
            String currentStatus = movement.getStatus().toString();
            String status = currentStatus.substring(currentStatus.indexOf("_") + 1);

            if (movement.getAssignedUser() == null) {
                movement.setStatus(Status.valueOf("UNASSIGNED_" + status));
            } else {
                movement.setStatus(Status.valueOf("ASSIGNED_" + status));
            }
        }

        UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
        Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
        movement.setUser(user);
        movement.setLastModified(new Timestamp(System.currentTimeMillis()));
        movement.setActive(true);
        List<MovementsProducts> savedProducts = movementsProductsRepository.findAllByMovementUid(movement.getUid());
        for (MovementsProducts savedProduct : savedProducts) {
            movementsProductsRepository.delete(savedProduct);
        }
        List<MovementsProducts> products = movement.getProducts();
        for (MovementsProducts product : products) {
            product.setMovement(movement);
            movementsProductsRepository.save(product);
        }
        Movements movementUpdated = movementsRepository.save(movement);
        this.generateMovementsHistory(movementUpdated);
        return new Response<>(movementUpdated, false, 200, "ok!");
    }

    // set pending sending an image in photo field
    @Transactional
    public Response<Movements> setPendingMovement(Movements movement) {
        Movements currentMovement = movementsRepository.findByUidAndActive(movement.getUid(), true);
        String currentStatus = currentMovement.getStatus().toString();
        if (currentStatus.contains("ASSIGNED")) {
            String status = currentStatus.substring(currentStatus.indexOf("_") + 1);
            currentMovement.setStatus(Status.valueOf("PENDING_" + status));
            currentMovement.setLastModified(new Timestamp(System.currentTimeMillis()));
            currentMovement.setPhoto(movement.getPhoto());
            Movements movementPending = movementsRepository.save(currentMovement);
            this.generateMovementsHistory(movementPending);
            return new Response<>(movementPending, false, 200, "ok!");
        } else {
            return new Response<>(null, true, 400, "Movement already assigned");
        }
    }


    @Transactional
    public Response<Movements> deleteMovement(String id) {
        Movements movement = movementsRepository.findByUidAndActive(id, true);
        movement.setLastModified(new Timestamp(System.currentTimeMillis()));
        movement.setActive(!movement.getActive());
        Movements movementDeleted = movementsRepository.save(movement);
        this.generateMovementsHistory(movementDeleted);
        return new Response<>(movementDeleted, false, 200, "ok!");
    }


}
