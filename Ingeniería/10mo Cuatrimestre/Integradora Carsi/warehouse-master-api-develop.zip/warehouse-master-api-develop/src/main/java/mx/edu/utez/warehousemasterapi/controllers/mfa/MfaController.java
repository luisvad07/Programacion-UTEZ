package mx.edu.utez.warehousemasterapi.controllers.mfa;


import mx.edu.utez.warehousemasterapi.dtos.mfa.MfaImageDto;
import mx.edu.utez.warehousemasterapi.services.mfa.MfaService;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("${apiPrefix}/mfa")
@CrossOrigin(value = {"*"})
public class MfaController {
    private final MfaService service;

    @Autowired
    public MfaController(MfaService service) {
        this.service = service;
    }

    @PostMapping("/activate")
    public ResponseEntity<Response<MfaImageDto>> activateMfa() {
        return service.activateMfa();
    }

    @DeleteMapping("/deactivate")
    public ResponseEntity<Response<Boolean>> deactivateMfa() {
        return service.deactivateMfa();
    }
}
