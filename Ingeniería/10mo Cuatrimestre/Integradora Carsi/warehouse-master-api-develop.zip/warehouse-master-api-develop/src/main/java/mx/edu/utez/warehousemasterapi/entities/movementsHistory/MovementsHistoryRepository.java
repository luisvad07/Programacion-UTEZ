package mx.edu.utez.warehousemasterapi.entities.movementsHistory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovementsHistoryRepository extends JpaRepository<MovementsHistory, String> {
    List<MovementsHistory> findAllByMovementUidAndActive(String movementUid, Boolean active);
    MovementsHistory findByUidAndActive(String uid, Boolean active);
}
