package mx.edu.utez.warehousemasterapi.entities.suppliers;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SuppliersRepository extends JpaRepository<Suppliers, String> {
    List<Suppliers> findAllByActiveOrderByLastModifiedDesc(Boolean active);
    List<Suppliers> findAllByActive(Boolean active);
    Suppliers findByUidAndActive(String uid, Boolean active);
}

