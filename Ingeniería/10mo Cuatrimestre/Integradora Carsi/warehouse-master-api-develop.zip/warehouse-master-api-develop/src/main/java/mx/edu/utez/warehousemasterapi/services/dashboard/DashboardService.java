package mx.edu.utez.warehousemasterapi.services.dashboard;

import mx.edu.utez.warehousemasterapi.entities.categories.Categories;
import mx.edu.utez.warehousemasterapi.entities.dashboard.Dashboard;
import mx.edu.utez.warehousemasterapi.entities.movements.MovementsRepository;
import mx.edu.utez.warehousemasterapi.entities.products.Products;
import mx.edu.utez.warehousemasterapi.entities.products.ProductsRepository;
import mx.edu.utez.warehousemasterapi.entities.users.UsersRepository;
import mx.edu.utez.warehousemasterapi.entities.warehouses.WarehousesRepository;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;

@Service
public class DashboardService {
    private final ProductsRepository productsRepository;
    private final WarehousesRepository warehousesRepository;
    private final UsersRepository usersRepository;
    private final MovementsRepository movementsRepository;

    public DashboardService(ProductsRepository productsRepository, WarehousesRepository warehousesRepository, UsersRepository usersRepository, MovementsRepository movementsRepository) {
        this.productsRepository = productsRepository;
        this.warehousesRepository = warehousesRepository;
        this.usersRepository = usersRepository;
        this.movementsRepository = movementsRepository;
    }

    @Transactional(readOnly = true)
    public Response<Dashboard> getDashboard() {
        // Calculate the timestamp for 10 days from now
        Timestamp tenDaysFromNow = new java.sql.Timestamp(System.currentTimeMillis() + 10L * 24 * 60 * 60 * 1000);

        // Find products that will expire within the next 10 days
        List<Products> productsToExpire = productsRepository.findAllByActiveAndExpirationDateLessThan(true, tenDaysFromNow);

        Dashboard dashboard = new Dashboard();
        dashboard.setActiveProducts(productsRepository.countByActive(true));
        dashboard.setActiveWarehouses(warehousesRepository.countByActive(true));
        dashboard.setActiveUsers(usersRepository.countByActive(true));
        dashboard.setActiveMovements(movementsRepository.countByActive(true));
        dashboard.setProductsToExpire(productsToExpire);

        return new Response<>(
                dashboard,
                false,
                200,
                "ok!"
        );
    }
}
