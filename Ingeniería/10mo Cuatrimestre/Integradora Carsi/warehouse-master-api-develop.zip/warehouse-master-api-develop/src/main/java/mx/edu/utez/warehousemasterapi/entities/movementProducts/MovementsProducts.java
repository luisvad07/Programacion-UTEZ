package mx.edu.utez.warehousemasterapi.entities.movementProducts;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.warehousemasterapi.entities.movements.Movements;
import mx.edu.utez.warehousemasterapi.entities.products.Products;
import mx.edu.utez.warehousemasterapi.entities.racks.Racks;
import mx.edu.utez.warehousemasterapi.entities.warehouses.Warehouses;
import org.hibernate.annotations.UuidGenerator;


@Entity
@Table(name = "movement_products")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MovementsProducts {
    @Id
    @UuidGenerator
    @Column(name = "uid")
    private String uid;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Products product;

    @ManyToOne
    @JoinColumn(name = "destination_rack_id")
    private Racks destinationRack;

    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    @ManyToOne
    @JoinColumn(name = "movement_id")
    @JsonIgnore
    private Movements movement;

}

