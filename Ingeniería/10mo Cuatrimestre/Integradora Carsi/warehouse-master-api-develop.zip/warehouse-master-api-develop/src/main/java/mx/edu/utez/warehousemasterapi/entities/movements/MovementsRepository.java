package mx.edu.utez.warehousemasterapi.entities.movements;

import java.util.List;

import mx.edu.utez.warehousemasterapi.enums.type.TypeMovement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface MovementsRepository extends JpaRepository<Movements, String> {
    List<Movements> findAllByActiveOrderByLastModifiedDesc(Boolean active);

    List<Movements> findAllByAssignedUserUid(String userUid);
    List<Movements> findAllByAssignedUserEmail(String userEmail);

    @Query(value = "SELECT m.* FROM movements m " +
            "JOIN movement_products mp ON m.uid = mp.movement_id " +
            "JOIN racks r ON mp.destination_rack_id = r.uid " +
            "JOIN warehouses w ON r.warehouse_id = w.uid " +
            "WHERE w.uid = ?1 AND m.active = true AND w.active = true AND r.active = true", nativeQuery = true)
    List<Movements> findAllMovementsByProductsRackWharehouseUid(String warehouseUid);
    List<Movements> findAllByUserEmailAndActive(String email, Boolean active);
    Movements findByUidAndActive(String uid, Boolean active);
    Integer countByActive(Boolean active);
}

