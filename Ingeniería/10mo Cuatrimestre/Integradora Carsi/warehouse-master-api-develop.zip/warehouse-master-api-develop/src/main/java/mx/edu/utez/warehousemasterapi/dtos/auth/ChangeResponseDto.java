package mx.edu.utez.warehousemasterapi.dtos.auth;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ChangeResponseDto {
    private String message;
}