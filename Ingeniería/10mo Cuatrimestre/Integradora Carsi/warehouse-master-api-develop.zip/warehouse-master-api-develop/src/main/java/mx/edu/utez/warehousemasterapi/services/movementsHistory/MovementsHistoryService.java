package mx.edu.utez.warehousemasterapi.services.movementsHistory;

import mx.edu.utez.warehousemasterapi.entities.movements.Movements;
import mx.edu.utez.warehousemasterapi.entities.movementsHistory.MovementsHistory;
import mx.edu.utez.warehousemasterapi.entities.movementsHistory.MovementsHistoryRepository;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class MovementsHistoryService {
    private final MovementsHistoryRepository movementsHistoryRepository;

    @Autowired
    public MovementsHistoryService(MovementsHistoryRepository movementsHistoryRepository) {
        this.movementsHistoryRepository = movementsHistoryRepository;
    }

    @Transactional(readOnly = true)
    public Response<List<MovementsHistory>> getMovementHistoryByUidAndActive(String id) {
        List<MovementsHistory> movements = movementsHistoryRepository.findAllByMovementUidAndActive(id, true);
        return new Response<>(movements, false, 200, "ok!");
    }


}
