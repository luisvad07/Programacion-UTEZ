package mx.edu.utez.warehousemasterapi.entities.warehouses;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WarehousesRepository extends JpaRepository<Warehouses, String> {
    List<Warehouses> findAllByActiveOrderByLastModifiedDesc(Boolean active);
    List<Warehouses> findAllByActiveNotNullOrderByLastModified();
    List<Warehouses> findAllByActiveAndUidOrderByLastModifiedDesc(Boolean active, String uid);
    List<Warehouses> findAllByUidOrderByLastModifiedDesc( String uid);
    Warehouses findByNameAndActive(String name, Boolean active);
    Warehouses findByUidAndActive(String uid, Boolean active);
    Integer countByActive(Boolean active);
}
