package mx.edu.utez.warehousemasterapi.dtos.mfa;

import jakarta.validation.constraints.NotNull;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MfaImageDto {
    @NotNull
    private String image;
    @NotNull
    private String key;
}
