package mx.edu.utez.warehousemasterapi.controllers.movements;

import mx.edu.utez.warehousemasterapi.entities.movements.Movements;
import mx.edu.utez.warehousemasterapi.services.movements.MovementsServices;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("${apiPrefix}/movements")
@CrossOrigin(value = {"*"})
public class MovementsController {
    private final MovementsServices movementsService;

    @Autowired
    public MovementsController(MovementsServices movementsService) {
        this.movementsService = movementsService;
    }

    @GetMapping("/")
    public ResponseEntity<Response<List<Movements>>> getAllMovements() {
        Response<List<Movements>> response = movementsService.getAllMovements();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Response<Movements>> getMovementById(@PathVariable String id) {
        Response<Movements> response = movementsService.getMovementById(id);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PostMapping("/")
    public ResponseEntity<Response<Movements>> saveMovement(@RequestBody Movements movement) {
        Response<Movements> response = movementsService.saveMovement(movement);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PostMapping("/cart")
    public ResponseEntity<Response<List<Movements>>> saveCartOfMovements(@RequestBody List<Movements> movements) {
        Response<List<Movements>> response = movementsService.saveCartOfMovements(movements);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/assign/{movementId}/{userId}")
    public ResponseEntity<Response<Movements>> assignMovementToUser(@PathVariable String movementId, @PathVariable String userId) {
        Response<Movements> response = movementsService.assignMovementToUser(movementId, userId);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/approved/{movementId}")
    public ResponseEntity<Response<Movements>> approvedMovement(@PathVariable String movementId) {
        Response<Movements> response = movementsService.approveMovement(movementId);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/cancel/{movementId}")
    public ResponseEntity<Response<Movements>> cancelMovement(@PathVariable String movementId) {
        Response<Movements> response = movementsService.cancelMovement(movementId);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/unassign/{movementId}")
    public ResponseEntity<Response<Movements>> unassignMovement(@PathVariable String movementId) {
        Response<Movements> response = movementsService.unassignMovement(movementId);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/pending/")
    public ResponseEntity<Response<Movements>> pendingMovement(@RequestBody Movements movement) {
        Response<Movements> response = movementsService.setPendingMovement(movement);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/")
    public ResponseEntity<Response<Movements>> updateMovement(@RequestBody Movements movement) {
        Response<Movements> response = movementsService.updateMovement(movement);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Response<Movements>> deleteMovement(@PathVariable String id) {
        Response<Movements> response = movementsService.deleteMovement(id);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }
}