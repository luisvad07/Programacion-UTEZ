package mx.edu.utez.warehousemasterapi.controllers.warehouses;

import mx.edu.utez.warehousemasterapi.entities.warehouses.Warehouses;
import mx.edu.utez.warehousemasterapi.services.warehouses.WarehousesService;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("${apiPrefix}/warehouses")
@CrossOrigin(value = {"*"})
public class WarehousesController {
    private final WarehousesService warehousesService;

    @Autowired
    public WarehousesController(WarehousesService warehousesService) {
        this.warehousesService = warehousesService;
    }

    @GetMapping("/")
    public ResponseEntity<Response<List<Warehouses>>> getAllWarehouses() {
        Response<List<Warehouses>> response = warehousesService.getAllWarehouses();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/name/{name}")
    public ResponseEntity<Response<Warehouses>> getWarehouseByName(@PathVariable String name) {
        Response<Warehouses> response = warehousesService.getWarehouseByName(name);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/{uid}")
    public ResponseEntity<Response<Warehouses>> getWarehouseByUid(@PathVariable String uid) {
        Response<Warehouses> response = warehousesService.getWarehouseByUid(uid);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PostMapping("/")
    public ResponseEntity<Response<Warehouses>> createWarehouse(@RequestBody Warehouses warehouse) {
        Response<Warehouses> response = warehousesService.createWarehouse(warehouse);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/")
    public ResponseEntity<Response<Warehouses>> updateWarehouse(@RequestBody Warehouses warehouse) {
        Response<Warehouses> response = warehousesService.updateWarehouse(warehouse);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @DeleteMapping("/{uid}")
    public ResponseEntity<Response<Warehouses>> deleteWarehouse(@PathVariable String uid) {
        Response<Warehouses> response = warehousesService.deleteWarehouse(uid);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }
}