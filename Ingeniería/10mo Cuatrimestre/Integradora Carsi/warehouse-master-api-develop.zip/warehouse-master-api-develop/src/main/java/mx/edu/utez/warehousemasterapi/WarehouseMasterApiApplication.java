package mx.edu.utez.warehousemasterapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WarehouseMasterApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(WarehouseMasterApiApplication.class, args);
    }

}
