package mx.edu.utez.warehousemasterapi.config;

import jakarta.annotation.PostConstruct;
import mx.edu.utez.warehousemasterapi.entities.users.UsersRepository;
import mx.edu.utez.warehousemasterapi.enums.roles.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.client.RestTemplate;
import mx.edu.utez.warehousemasterapi.entities.users.Users;

@Configuration
public class AppConfig {
    private final PasswordEncoder passwordEncoder;
    private final UsersRepository usersRepository;



    @Autowired
    public AppConfig(PasswordEncoder passwordEncoder, UsersRepository usersRepository) {

        this.passwordEncoder = passwordEncoder;
        this.usersRepository = usersRepository;
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @PostConstruct
    public void init() {
        if(usersRepository.count() == 0)
        {
            // Create default user
            Users user = new Users();
            user.setEmail("redalphasiete@gmail.com");
            user.setActive(true);
            user.setRole(Role.valueOf("SUPER_ADMIN"));
            user.setName("Super Admin");
            user.setPassword(passwordEncoder.encode("123456"));
            usersRepository.save(user);
        }
    }


}
