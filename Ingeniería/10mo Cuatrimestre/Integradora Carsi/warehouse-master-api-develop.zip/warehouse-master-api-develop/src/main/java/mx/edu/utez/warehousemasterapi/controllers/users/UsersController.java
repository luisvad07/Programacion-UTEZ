package mx.edu.utez.warehousemasterapi.controllers.users;

import mx.edu.utez.warehousemasterapi.dtos.users.UsersDto;
import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.enums.roles.Role;
import mx.edu.utez.warehousemasterapi.services.users.UsersServices;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("${apiPrefix}/users")
@CrossOrigin(value = {"*"})
public class UsersController {
    @Autowired
    private UsersServices services;

    @GetMapping("/get-all")
    public ResponseEntity<Response<List<Users>>> getAll() {
        Response<List<Users>> response = services.getAllUsers();
        return new ResponseEntity<>(
                response,
                HttpStatus.valueOf(response.getStatus())
        );
    }

    @GetMapping("/get-user-email/{email}")
    public ResponseEntity<Response<Users>> getUserEmail(@PathVariable String email) {
        Response<Users> response = services.getUserByEmail(email);
        return new ResponseEntity<>(
                response,
                HttpStatus.valueOf(response.getStatus())
        );
    }
    @GetMapping("/get-user-uid/{uid}")
    public ResponseEntity<Response<Users>> getUserUid(@PathVariable String uid) {
        Response<Users> response = services.getUserById(uid);
        return new ResponseEntity<>(
                response,
                HttpStatus.valueOf(response.getStatus())
        );
    }
    @GetMapping("/role/{role}")
    public ResponseEntity<Response<List<Users>>> getAllByRole(@PathVariable String role) {
        Response<List<Users>> response = services.getAllUsersByRole(Role.valueOf(role));
        return new ResponseEntity<>(
                response,
                HttpStatus.valueOf(response.getStatus())
        );
    }
    @PostMapping("/create")
    public ResponseEntity<Response<Users>> create(@RequestBody UsersDto usersDto) {
        Response<Users> response = services.createUser(usersDto.getUser());
        return new ResponseEntity<>(
                response,
                HttpStatus.valueOf(response.getStatus())
        );
    }
    @PutMapping("/update")
    public ResponseEntity<Response<Users>> update(@RequestBody UsersDto usersDto) {
        Response<Users> response = services.updateUser(usersDto.getUser());
        return new ResponseEntity<>(
                response,
                HttpStatus.valueOf(response.getStatus())
        );
    }
    @DeleteMapping("/delete/{uid}")
    public ResponseEntity<Response<Users>> delete(@PathVariable String uid) {
        Response<Users> response = services.deleteUser(uid);
        return new ResponseEntity<>(
                response,
                HttpStatus.valueOf(response.getStatus())
        );
    }
    @DeleteMapping("/change-status/{uid}")
    public ResponseEntity<Response<Users>> changeStatus(@PathVariable String uid) {
        Response<Users> response = services.changeStatus(uid);
        return new ResponseEntity<>(
                response,
                HttpStatus.valueOf(response.getStatus())
        );
    }
}
