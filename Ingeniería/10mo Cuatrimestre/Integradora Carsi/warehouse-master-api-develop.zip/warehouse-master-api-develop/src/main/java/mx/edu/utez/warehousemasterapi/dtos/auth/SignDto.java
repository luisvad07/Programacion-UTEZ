package mx.edu.utez.warehousemasterapi.dtos.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class SignDto {
    @NotBlank
    @NotEmpty
    @Email(message = "The email must be valid")
    private String email;
    @NotBlank
    @NotEmpty

    private String password;
}
