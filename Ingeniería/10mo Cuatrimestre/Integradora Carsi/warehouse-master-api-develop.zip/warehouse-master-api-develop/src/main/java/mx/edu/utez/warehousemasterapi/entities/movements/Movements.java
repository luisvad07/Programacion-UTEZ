package mx.edu.utez.warehousemasterapi.entities.movements;

import java.sql.Timestamp;
import java.util.List;

import mx.edu.utez.warehousemasterapi.entities.movementProducts.MovementsProducts;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.enums.status.Status;

@Entity
@Table(name = "movements")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Movements {
    @Id
    @UuidGenerator
    @Column(name = "uid")
    private String uid;

    @OneToMany
    @JoinColumn(name = "movement_id")
    private List<MovementsProducts> products;

    @ManyToOne
    @JoinColumn(name = "created_by", nullable = false)
    private Users user;

    @Column(name = "photo", columnDefinition = "MEDIUMTEXT")
    private String photo;

    @Column(name = "observations", columnDefinition = "TEXT")
    private String observations;

    @Column(columnDefinition = "ENUM('UNASSIGNED_ENTRY', 'UNASSIGNED_EXIT', 'UNASSIGNED_TRANSFER', 'UNASSIGNED_ADJUSTMENT','ASSIGNED_ENTRY', 'ASSIGNED_EXIT', 'ASSIGNED_TRANSFER', 'ASSIGNED_ADJUSTMENT','PENDING_ENTRY', 'PENDING_EXIT', 'PENDING_TRANSFER', 'PENDING_ADJUSTMENT', 'ENTRY', 'EXIT', 'TRANSFER', 'ADJUSTMENT','CANCELLED') NOT NULL DEFAULT 'EXIT'")
    @Enumerated(EnumType.STRING)
    private Status status;

    @Column(name = "active", columnDefinition = "BOOLEAN DEFAULT TRUE")
    private Boolean active;

    @Column(name = "last_modified", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp lastModified;

    @ManyToOne
    @JoinColumn(name = "assigned_user_id")
    private Users assignedUser;
}