package mx.edu.utez.warehousemasterapi.services.products;


import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import mx.edu.utez.warehousemasterapi.entities.movementProducts.MovementsProducts;
import mx.edu.utez.warehousemasterapi.entities.movementProducts.MovementsProductsRepository;
import mx.edu.utez.warehousemasterapi.entities.movements.Movements;
import mx.edu.utez.warehousemasterapi.entities.movements.MovementsRepository;
import mx.edu.utez.warehousemasterapi.entities.movementsHistory.MovementsHistory;
import mx.edu.utez.warehousemasterapi.entities.movementsHistory.MovementsHistoryRepository;
import mx.edu.utez.warehousemasterapi.entities.products.Products;
import mx.edu.utez.warehousemasterapi.entities.products.ProductsRepository;
import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.entities.users.UsersRepository;
import mx.edu.utez.warehousemasterapi.entities.warehouses.Warehouses;
import mx.edu.utez.warehousemasterapi.enums.status.Status;
import mx.edu.utez.warehousemasterapi.utils.CurrentUserDetails;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class ProductsService {

    private final ProductsRepository productsRepository;
    private final CurrentUserDetails currentUserDetails;
    private final UsersRepository usersRepository;
    private final MovementsRepository movementsRepository;
    private final MovementsHistoryRepository movementsHistoryRepository;
    private final MovementsProductsRepository movementsProductsRepository;


    @Autowired
    public ProductsService(ProductsRepository productsRepository, CurrentUserDetails currentUserDetails, UsersRepository usersRepository, MovementsRepository movementsRepository, MovementsHistoryRepository movementsHistoryRepository, MovementsProductsRepository movementsProductsRepository) {
        this.productsRepository = productsRepository;
        this.currentUserDetails = currentUserDetails;
        this.usersRepository = usersRepository;
        this.movementsRepository = movementsRepository;
        this.movementsHistoryRepository = movementsHistoryRepository;
        this.movementsProductsRepository = movementsProductsRepository;
    }

    private String generateQrCode(String data) {

        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = qrCodeWriter.encode(data, BarcodeFormat.QR_CODE, 200, 200);
            BufferedImage qrCodeImage = toBufferedImage(bitMatrix);

            return generateDataUri(qrCodeImage);
        } catch (WriterException | IOException e) {
            throw new RuntimeException("Error al generar el código QR", e);
        }
    }

    private BufferedImage toBufferedImage(BitMatrix matrix) {
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                image.setRGB(x, y, matrix.get(x, y) ? Color.BLACK.getRGB() : Color.WHITE.getRGB());
            }
        }
        return image;
    }

    private String generateDataUri(BufferedImage image) throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            ImageIO.write(image, "png", baos);
            return "data:image/png;base64," + Base64.getEncoder().encodeToString(baos.toByteArray());
        }
    }

    @Transactional(readOnly = true)
    public Response<List<Products>> getAllProductsByActive(Boolean active) {

        List<Products> products;
        Set<String> roles = currentUserDetails.getCurrentUserAuthorities();
        if (roles.contains("ADMIN")) {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            Warehouses warehouse = user.getWarehouse();
            products = productsRepository.findAllByActiveAndRackWarehouseUidOrderByLastModifiedDesc(active, warehouse.getUid());
        } else {
            products = productsRepository.findAllByActiveOrderByLastModifiedDesc(active);
        }

        products.forEach(product -> {
            product.setQrCode(generateQrCode(product.getUid()));
        });


        return new Response<>(products, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<List<Products>> getAllProducts() {

        List<Products> products;
        Set<String> roles = currentUserDetails.getCurrentUserAuthorities();
        if (roles.contains("ADMIN")) {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            Warehouses warehouse = user.getWarehouse();
            products = productsRepository.findAllByRackWarehouseUidOrderByLastModifiedDesc(warehouse.getUid());
        } else {
            products = productsRepository.findAllByActiveNotNullOrderByLastModifiedDesc();
        }

        products.forEach(product -> {
            product.setQrCode(generateQrCode(product.getUid()));
        });


        return new Response<>(products, false, 200, "ok!");
    }


    @Transactional(readOnly = true)
    public Response<Products> getProductById(String id) {
        Products product = productsRepository.findByUidAndActive(id, true);
        product.setQrCode(generateQrCode(product.getUid()));
        return new Response<>(product, false, 200, "ok!");
    }

    @Transactional
    public Response<Products> saveProduct(Products product) {
        product.setActive(true);
        product.setLastModified(new Timestamp(System.currentTimeMillis()));
        Products productSaved = productsRepository.save(product);
        // genera un movimiento de entrada
        UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
        Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
        Movements movement = new Movements();
        movement.setStatus(Status.ENTRY);
        movement.setActive(true);
        movement.setLastModified(new Timestamp(System.currentTimeMillis()));
        movement.setObservations("Entrada de producto");
        movement.setUser(user);
        Movements movementSaved = movementsRepository.save(movement);
        MovementsProducts movementsProducts = new MovementsProducts();
        movementsProducts.setProduct(productSaved);
        movementsProducts.setMovement(movementSaved);
        movementsProducts.setQuantity(productSaved.getStock());
        movementsProductsRepository.save(movementsProducts);

        generateMovementsHistory(movementSaved);
        return new Response<>(productSaved, false, 200, "ok!");
    }

    public void generateMovementsHistory(Movements movement) {

        UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
        Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
        MovementsHistory movementsHistory = new MovementsHistory();
        movementsHistory.setMovement(movement);
        movementsHistory.setLastModified(new Timestamp(System.currentTimeMillis()));
        movementsHistory.setStatus(movement.getStatus());
        movementsHistory.setUser(user);
        movementsHistoryRepository.save(movementsHistory);
    }

    @Transactional
    public Response<Products> updateProduct(Products product) {
        Products productUpdated = productsRepository.save(product);
        // genera un movimiento de ajuste
        Movements movement = new Movements();
        UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
        Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
        movement.setStatus(Status.ADJUSTMENT);
        movement.setActive(true);
        movement.setLastModified(new Timestamp(System.currentTimeMillis()));
        movement.setObservations("Ajuste de producto");
        movement.setUser(user);
        Movements movementSaved = movementsRepository.save(movement);
        MovementsProducts movementsProducts = new MovementsProducts();
        movementsProducts.setProduct(productUpdated);
        movementsProducts.setMovement(movementSaved);
        movementsProducts.setQuantity(productUpdated.getStock());
        movementsProductsRepository.save(movementsProducts);
        generateMovementsHistory(movementSaved);
        return new Response<>(productUpdated, false, 200, "ok!");
    }

    @Transactional
    public Response<Products> deleteProduct(String id) {
        Optional<Products> product = productsRepository.findById(id);
        if (product.isPresent()) {
            product.get().setActive(!product.get().getActive());
            product.get().setLastModified(new Timestamp(System.currentTimeMillis()));
            Products productDeleted = productsRepository.save(product.get());
            return new Response<>(productDeleted, false, 200, "ok!");
        }
        return new Response<>(null, true, 404, "Not Found");
    }


}
