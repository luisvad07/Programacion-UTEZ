package mx.edu.utez.warehousemasterapi.services.auth;

import mx.edu.utez.warehousemasterapi.dtos.auth.*;
import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.entities.users.UsersRepository;
import mx.edu.utez.warehousemasterapi.entities.warehouses.Warehouses;
import mx.edu.utez.warehousemasterapi.entities.warehouses.WarehousesRepository;
import mx.edu.utez.warehousemasterapi.security.jwt.JwtProvider;
import mx.edu.utez.warehousemasterapi.services.mailservice.MailService;
import mx.edu.utez.warehousemasterapi.services.mfa.MfaService;
import mx.edu.utez.warehousemasterapi.utils.HtmlMessageRender;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.logging.Logger;

@Service
@Transactional
public class AuthService {

    private final Logger logger = Logger.getLogger(AuthService.class.getName());


    private final AuthenticationManager manager;

    private final JwtProvider provider;

    private final MailService emailService;

    private final HtmlMessageRender htmlRender;
    private final PasswordEncoder passwordEncoder;
    private final UsersRepository repository;
    private final MfaService mfaService;
    private final WarehousesRepository warehousesRepository;

    @Autowired
    public AuthService(AuthenticationManager manager, JwtProvider provider, MailService emailService, HtmlMessageRender htmlRender, PasswordEncoder passwordEncoder, UsersRepository repository, MfaService mfaService, WarehousesRepository warehousesRepository) {

        this.manager = manager;
        this.provider = provider;
        this.emailService = emailService;
        this.htmlRender = htmlRender;
        this.passwordEncoder = passwordEncoder;
        this.repository = repository;
        this.mfaService = mfaService;
        this.warehousesRepository = warehousesRepository;
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Response<UserTokenDto>> login(SignDto dto) {
        try {
            Users foundUser = repository.findByEmailAndActive(dto.getEmail(), true);
            if (foundUser.getWarehouse() != null) {
                Warehouses warehouse = warehousesRepository.findByUidAndActive(foundUser.getWarehouse().getUid(), true);
                if (warehouse == null) {
                    return new ResponseEntity<>(new Response<>(null, true, 404, "Warehouse not found"), HttpStatus.NOT_FOUND);
                }
            }
            if (foundUser == null)
                return new ResponseEntity<>(new Response<>(null, true, 404, "User not found"), HttpStatus.NOT_FOUND);
            if (Boolean.FALSE.equals(foundUser.getActive())) {
                return new ResponseEntity<>(new Response<>(null, true, 401, "User inactive"), HttpStatus.UNAUTHORIZED);
            }
            if (!passwordEncoder.matches(dto.getPassword(), foundUser.getPassword())) {
                return new ResponseEntity<>(new Response<>(null, true, 401, "Incorrect credentials"), HttpStatus.UNAUTHORIZED);
            }
            if (foundUser.getMfaEnabled() != null && foundUser.getMfaEnabled()) {
                return new ResponseEntity<>(new Response<>(null, true, 200, "MFA required"), HttpStatus.OK);
            }
            Authentication auth = manager.authenticate(new UsernamePasswordAuthenticationToken(dto.getEmail(), dto.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(auth);
            String token = provider.generateToken(auth);
            UserTokenDto data = new UserTokenDto(token, foundUser);
            return new ResponseEntity<>(new Response<>(data, false, 200, "OK"), HttpStatus.OK);
        } catch (Exception e) {
            this.logger.severe(e.getMessage());
            String message = "Something went wrong";
            if (e instanceof DisabledException) message = "User inactive";
            return new ResponseEntity<>(new Response<>(null, true, 401, message), HttpStatus.BAD_REQUEST);
        }
    }

    public ResponseEntity<Response<ChangeResponseDto>> resetPassword(ChangeRequestDto dto) {

        String correo = dto.getEmail();
        Users user = repository.findByEmailAndActive(correo, true);
        if (user == null) {
            return new ResponseEntity<>(new Response<>(null, true, 404, "User not found"), HttpStatus.NOT_FOUND);
        }
        String token = provider.generatePasswordResetToken(correo);
        String url = "http://localhost:5173/restablecer?token=" + token;
        String message = htmlRender.renderRecover(user.getName(), url);
        try {
            emailService.sendHtmlMessage(correo, "Recuperar contraseña", message);
            return new ResponseEntity<>(new Response<>(new ChangeResponseDto(correo), false, 200, "Email sent"), HttpStatus.OK);
        } catch (Exception e) {
            this.logger.severe(e.getMessage());
            return new ResponseEntity<>(new Response<>(null, true, 500, "Error sending email"), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    public ResponseEntity<Response<ChangeResponseDto>> confirmResetPassword(String token, String password) {
        String correo = provider.getEmailFromPasswordResetToken(token);
        Users user = repository.findByEmailAndActive(correo, true);
        if (user == null) {
            return new ResponseEntity<>(new Response<>(null, true, 404, "Usuario no encontrado"), HttpStatus.NOT_FOUND);
        }
        user.setPassword(passwordEncoder.encode(password));
        repository.saveAndFlush(user);
        return new ResponseEntity<>(new Response<>(new ChangeResponseDto(correo), false, 200, "Contraseña actualizada"), HttpStatus.OK);
    }

    public ResponseEntity<Response<UserTokenDto>> verifyMfa(MfaVerificationDto dto) {
    try {
        String email = dto.getEmail();
        String mfaCode = dto.getMfaCode();
        String password = dto.getPassword();
        Users user = repository.findByEmailAndActive(email, true);
        if (user == null) {
            return new ResponseEntity<>(new Response<>(null, true, 404, "User not found"), HttpStatus.NOT_FOUND);
        }
        boolean isCodeValid = mfaService.validateMfa(user.getMfaDevice().getSecretKey(), mfaCode);
        if (!isCodeValid) {
            return new ResponseEntity<>(new Response<>(null, true, 401, "Invalid MFA code"), HttpStatus.UNAUTHORIZED);
        }
        Authentication auth = manager.authenticate(new UsernamePasswordAuthenticationToken(email, password));
        SecurityContextHolder.getContext().setAuthentication(auth);
        String token = provider.generateToken(auth);
        UserTokenDto data = new UserTokenDto(token, user);
        return new ResponseEntity<>(new Response<>(data, false, 200, "OK"), HttpStatus.OK);
    } catch (Exception e) {
        this.logger.severe(e.getMessage());
        return new ResponseEntity<>(new Response<>(null, true, 500, "Error verifying MFA: " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

}
