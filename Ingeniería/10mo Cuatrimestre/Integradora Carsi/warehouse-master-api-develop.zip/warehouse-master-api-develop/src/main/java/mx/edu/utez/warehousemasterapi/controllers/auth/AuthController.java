package mx.edu.utez.warehousemasterapi.controllers.auth;


import jakarta.validation.Valid;
import mx.edu.utez.warehousemasterapi.dtos.auth.*;
import mx.edu.utez.warehousemasterapi.services.auth.AuthService;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("${apiPrefix}/auth")
@CrossOrigin(value = {"*"})
public class AuthController {
    private final AuthService service;

    public AuthController(AuthService service) {
        this.service = service;
    }

    @PostMapping("/")
    public ResponseEntity<Response<UserTokenDto>> login(@RequestBody @Valid SignDto dto) {
        return service.login(dto);
    }

    @PostMapping("/restore")
    public ResponseEntity<Response<ChangeResponseDto>> restorePassword(@RequestBody @Valid ChangeRequestDto dto) {
        return service.resetPassword(dto);
    }
    @PostMapping("/verify-mfa")
    public ResponseEntity<Response<UserTokenDto>> verifyMfa(@RequestBody MfaVerificationDto dto) {
        return service.verifyMfa(dto);
    }

    @PostMapping("/confirm")
    public ResponseEntity<Response<ChangeResponseDto>> confirmChange(@RequestBody @Valid RestorePassDto dto) {
        return service.confirmResetPassword(dto.getToken(), dto.getPassword());
    }
}
