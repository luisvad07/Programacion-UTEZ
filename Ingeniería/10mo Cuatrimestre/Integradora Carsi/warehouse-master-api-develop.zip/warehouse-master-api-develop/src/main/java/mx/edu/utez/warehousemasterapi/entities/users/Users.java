package mx.edu.utez.warehousemasterapi.entities.users;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import mx.edu.utez.warehousemasterapi.entities.mfa.MfaDevice;
import mx.edu.utez.warehousemasterapi.entities.warehouses.Warehouses;
import mx.edu.utez.warehousemasterapi.enums.roles.Role;
import org.hibernate.annotations.UuidGenerator;

import java.sql.Timestamp;

@Entity
@Table(name = "users")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class Users {
    @Id
    @UuidGenerator
    @Column(name = "uid")
    private String uid;
    @Column(name = "name", columnDefinition = "TEXT NOT NULL")
    private String name;
    @Column(name = "email", columnDefinition = "TEXT NOT NULL")
    private String email;
    @Column(name = "password", columnDefinition = "TEXT NOT NULL")
    private String password;
    @Column(name = "last_modified", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp lastModified;
    @Column(columnDefinition = "ENUM('SUPER_ADMIN', 'ADMIN', 'WAREHOUSE_WORKER', 'CLIENT') DEFAULT 'CLIENT'")
    @Enumerated(EnumType.STRING)
    private Role role;
    @ManyToOne
    @JoinColumn(name = "warehouse_id")
    private Warehouses warehouse;
    @Column(name = "active", columnDefinition = "BOOLEAN DEFAULT TRUE")
    private Boolean active;

    @Column(name = "mfa_enabled", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private Boolean mfaEnabled;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private MfaDevice mfaDevice;

}