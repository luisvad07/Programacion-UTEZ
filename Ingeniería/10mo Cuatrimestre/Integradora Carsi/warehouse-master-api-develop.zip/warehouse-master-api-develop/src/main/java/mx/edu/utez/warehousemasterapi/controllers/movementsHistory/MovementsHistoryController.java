package mx.edu.utez.warehousemasterapi.controllers.movementsHistory;

import mx.edu.utez.warehousemasterapi.entities.movementsHistory.MovementsHistory;
import mx.edu.utez.warehousemasterapi.services.movementsHistory.MovementsHistoryService;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("${apiPrefix}/movementsHistory")
@CrossOrigin(value = {"*"})
public class MovementsHistoryController {
    private final MovementsHistoryService movementsHistoryService;

    @Autowired
    public MovementsHistoryController(MovementsHistoryService movementsHistoryService) {
        this.movementsHistoryService = movementsHistoryService;
    }

    @GetMapping("/{uid}")
    public ResponseEntity<Response<List<MovementsHistory>>> getMovementHistoryByUidAndActive(@PathVariable String uid) {
        Response<List<MovementsHistory>> response = movementsHistoryService.getMovementHistoryByUidAndActive(uid);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

}
