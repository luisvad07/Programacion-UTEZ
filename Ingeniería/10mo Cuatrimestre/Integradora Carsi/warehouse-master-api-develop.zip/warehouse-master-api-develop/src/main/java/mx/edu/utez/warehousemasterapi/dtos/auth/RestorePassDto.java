package mx.edu.utez.warehousemasterapi.dtos.auth;


import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class RestorePassDto {
    @NotBlank
    private String token;
    @NotBlank
    private String password;
}

