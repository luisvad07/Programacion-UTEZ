package mx.edu.utez.warehousemasterapi.services.mfa;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.warrenstrange.googleauth.GoogleAuthenticator;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;
import mx.edu.utez.warehousemasterapi.dtos.mfa.MfaImageDto;
import mx.edu.utez.warehousemasterapi.entities.mfa.MfaDevice;
import mx.edu.utez.warehousemasterapi.entities.mfa.MfaDeviceRepository;
import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.entities.users.UsersRepository;
import mx.edu.utez.warehousemasterapi.utils.CurrentUserDetails;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;

@Service
public class MfaService {

    private final UsersRepository usersRepository;
    private final MfaDeviceRepository mfaDeviceRepository;
    private final CurrentUserDetails currentUserDetails;

    @Autowired
    public MfaService(UsersRepository usersRepository, MfaDeviceRepository mfaDeviceRepository, CurrentUserDetails currentUserDetails) {
        this.usersRepository = usersRepository;
        this.mfaDeviceRepository = mfaDeviceRepository;
        this.currentUserDetails = currentUserDetails;
    }

    public ResponseEntity<Response<MfaImageDto>> activateMfa() {
        try {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            GoogleAuthenticator ga = new GoogleAuthenticator();
            GoogleAuthenticatorKey key = ga.createCredentials();
            String secretKey = key.getKey();
            MfaDevice mfaDevice = new MfaDevice();
            mfaDevice.setSecretKey(secretKey);
            mfaDevice.setUser(user);
            mfaDeviceRepository.save(mfaDevice);
            user.setMfaDevice(mfaDevice);
            user.setMfaEnabled(true);
            usersRepository.save(user);
            String qrCodeDataUri = generateQrCodeDataUri(secretKey, user.getEmail());
            MfaImageDto mfaImageDto = new MfaImageDto(qrCodeDataUri, secretKey);
            return new ResponseEntity<>(new Response<>(mfaImageDto, true, 200, "MFA activated re-login to use it"), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(new Response<>(null, true, 500, "Error activating MFA: " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Response<Boolean>> deactivateMfa() {
        try {
            UserDetails userDetails = currentUserDetails.getCurrentUserDetails();
            Users user = usersRepository.findByEmailAndActive(userDetails.getUsername(), true);
            MfaDevice mfaDevice = mfaDeviceRepository.findByUser_Uid(user.getUid()).orElseThrow(() -> new RuntimeException("MFA device not found"));
            mfaDeviceRepository.delete(mfaDevice);
            user.setMfaDevice(null);
            user.setMfaEnabled(false);
            usersRepository.save(user);
            return new ResponseEntity<>(new Response<>(true, true, 200, "MFA deactivated"), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(new Response<>(false, true, 500, "Error deactivating MFA: " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private String generateQrCodeDataUri(String secretKey, String email) {
        String otpAuthURL = "otpauth://totp/" + "Warehouse%20Master:" + email + "?secret=" + secretKey + "&issuer=Warehouse%20Master";

        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = qrCodeWriter.encode(otpAuthURL, BarcodeFormat.QR_CODE, 200, 200);
            BufferedImage qrCodeImage = toBufferedImage(bitMatrix);

            return generateDataUri(qrCodeImage);
        } catch (WriterException | IOException e) {
            throw new RuntimeException("Error al generar el código QR", e);
        }
    }

    private BufferedImage toBufferedImage(BitMatrix matrix) {
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                image.setRGB(x, y, matrix.get(x, y) ? Color.BLACK.getRGB() : Color.WHITE.getRGB());
            }
        }
        return image;
    }

    private String generateDataUri(BufferedImage image) throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            ImageIO.write(image, "png", baos);
            return "data:image/png;base64," + Base64.getEncoder().encodeToString(baos.toByteArray());
        }
    }

    public boolean validateMfa(String secretKey, String mfaCode) {
        GoogleAuthenticator ga = new GoogleAuthenticator();
        try {
            int code = Integer.parseInt(mfaCode);
            return ga.authorize(secretKey, code);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid MFA code format", e);
        }
    }
}