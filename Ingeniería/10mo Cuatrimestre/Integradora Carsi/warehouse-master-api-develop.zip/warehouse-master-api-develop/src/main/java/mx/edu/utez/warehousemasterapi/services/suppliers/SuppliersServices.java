package mx.edu.utez.warehousemasterapi.services.suppliers;

import mx.edu.utez.warehousemasterapi.entities.suppliers.Suppliers;
import mx.edu.utez.warehousemasterapi.entities.suppliers.SuppliersRepository;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Service
public class SuppliersServices {
    private final SuppliersRepository suppliersRepository;

    @Autowired
    public SuppliersServices(SuppliersRepository suppliersRepository) {
        this.suppliersRepository = suppliersRepository;
    }

    @Transactional(readOnly = true)
    public Response<List<Suppliers>> getAllSuppliersByActive(Boolean active) {
        List<Suppliers> suppliers = suppliersRepository.findAllByActiveOrderByLastModifiedDesc(active);
        return new Response<>(suppliers, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<List<Suppliers>> getAllSuppliers() {
        List<Suppliers> suppliers = suppliersRepository.findAll();
        return new Response<>(suppliers, false, 200, "ok!");
    }

    @Transactional(readOnly = true)
    public Response<Suppliers> getSupplierById(String id) {
        Suppliers supplier = suppliersRepository.findByUidAndActive(id, true);
        return new Response<>(supplier, false, 200, "ok!");
    }

    @Transactional
    public Response<Suppliers> saveSupplier(Suppliers supplier) {
        supplier.setActive(true);
        supplier.setLastModified(new Timestamp(System.currentTimeMillis()));
        Suppliers supplierSaved = suppliersRepository.save(supplier);
        return new Response<>(supplierSaved, false, 200, "ok!");
    }

    @Transactional
    public Response<Suppliers> updateSupplier(Suppliers supplier) {
        supplier.setLastModified(new Timestamp(System.currentTimeMillis()));
        Suppliers supplierUpdated = suppliersRepository.save(supplier);
        return new Response<>(supplierUpdated, false, 200, "ok!");
    }

    @Transactional
    public Response<Suppliers> deleteSupplier(String id) {
        Optional<Suppliers> supplier = suppliersRepository.findById(id);
        if (supplier.isPresent()) {
            supplier.get().setActive(!supplier.get().getActive());
            supplier.get().setLastModified(new Timestamp(System.currentTimeMillis()));
            Suppliers supplierDeleted = suppliersRepository.save(supplier.get());
            return new Response<>(supplierDeleted, false, 200, "ok!");
        }
        return new Response<>(null, true, 404, "Not Found");
    }

    @Transactional(readOnly = true)
    public Response<List<Suppliers>> getSuppliersByActive(Boolean active) {
        List<Suppliers> suppliers = suppliersRepository.findAllByActive(active);
        return new Response<>(suppliers, false, 200, "ok!");
    }


}
