package mx.edu.utez.warehousemasterapi.dtos.users;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.warehousemasterapi.entities.mfa.MfaDevice;
import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.entities.warehouses.Warehouses;
import mx.edu.utez.warehousemasterapi.enums.roles.Role;

import java.sql.Timestamp;

import jakarta.validation.constraints.*;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class UsersDto {

    private String uid;

    @NotBlank(message = "El nombre no puede estar en blanco")
    @Size(min = 2, max = 100, message = "El nombre debe tener entre 2 y 100 caracteres")
    private String name;

    @NotBlank(message = "El correo electrónico no puede estar en blanco")
    @Email(message = "Debe ser un correo electrónico válido")
    private String email;

    @NotBlank(message = "La contraseña no puede estar en blanco")
    @Size(min = 8, message = "La contraseña debe tener al menos 8 caracteres")
    private String password;

    private Timestamp lastModified;

    @NotNull(message = "El rol no puede ser nulo")
    private Role role;

    private Warehouses warehouse;

    @NotNull(message = "El estado activo no puede ser nulo")
    private Boolean active;

    private boolean mfaEnabled;

    private MfaDevice mfaDevice;

    public Users getUser() {
        this.lastModified = new Timestamp(System.currentTimeMillis());
        return new Users(
                uid,
                name,
                email,
                password,
                lastModified,
                role,
                warehouse,
                active,
                mfaEnabled,
                mfaDevice
        );
    }
}

