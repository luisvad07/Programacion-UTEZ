package mx.edu.utez.warehousemasterapi.entities.categories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoriesRepository extends JpaRepository<Categories, String> {
    List<Categories> findAllByActiveOrderByLastModifiedDesc(Boolean active);
    Categories findByNameAndActive(String name, Boolean active);
    Categories findByUidAndActive(String uid, Boolean active);
}
