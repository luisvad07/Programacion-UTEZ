package mx.edu.utez.warehousemasterapi.entities.mfa;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import mx.edu.utez.warehousemasterapi.entities.users.Users;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Table(name = "mfa_devices")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class MfaDevice {
    @Id
    @UuidGenerator
    @Column(name = "uid")
    private String uid;

    @Column(nullable = false, unique = true)
    private String secretKey;

    @JsonIgnore
    @OneToOne
    @JoinColumn(name = "user_uid", referencedColumnName = "uid")
    private Users user;
}