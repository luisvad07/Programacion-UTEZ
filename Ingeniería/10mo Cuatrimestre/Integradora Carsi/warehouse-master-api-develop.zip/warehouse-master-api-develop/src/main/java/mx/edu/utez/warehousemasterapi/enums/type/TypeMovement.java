package mx.edu.utez.warehousemasterapi.enums.type;

public enum TypeMovement {
    INTERNAL,
    EXTERNAL
}
