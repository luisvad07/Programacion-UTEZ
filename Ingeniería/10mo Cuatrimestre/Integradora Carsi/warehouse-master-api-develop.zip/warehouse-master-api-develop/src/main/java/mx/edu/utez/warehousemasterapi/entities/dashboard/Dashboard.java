package mx.edu.utez.warehousemasterapi.entities.dashboard;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mx.edu.utez.warehousemasterapi.entities.products.Products;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Dashboard {
    Integer activeUsers;
    Integer activeWarehouses;
    Integer activeProducts;
    Integer activeMovements;
    List<Products> productsToExpire;
}
