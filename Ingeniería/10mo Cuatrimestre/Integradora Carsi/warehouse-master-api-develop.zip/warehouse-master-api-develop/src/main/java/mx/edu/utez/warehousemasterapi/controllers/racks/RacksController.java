package mx.edu.utez.warehousemasterapi.controllers.racks;

import mx.edu.utez.warehousemasterapi.entities.racks.Racks;
import mx.edu.utez.warehousemasterapi.services.racks.RacksServices;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("${apiPrefix}/racks")
@CrossOrigin(value = {"*"})
public class RacksController {
    private final RacksServices racksService;

    @Autowired
    public RacksController(RacksServices racksService) {
        this.racksService = racksService;
    }

    @GetMapping("/")
    public ResponseEntity<Response<List<Racks>>> getAllRacks() {
        Response<List<Racks>> response = racksService.getAllRacks();
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/active/{active}")
    public ResponseEntity<Response<List<Racks>>> getAllRacksByActive(@PathVariable Boolean active) {
        Response<List<Racks>> response = racksService.getAllRacksByActive(active);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Response<Racks>> getRackById(@PathVariable String id) {
        Response<Racks> response = racksService.getRackById(id);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PostMapping("/")
    public ResponseEntity<Response<Racks>> saveRack(@RequestBody Racks rack) {
        Response<Racks> response = racksService.saveRack(rack);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @PutMapping("/")
    public ResponseEntity<Response<Racks>> updateRack(@RequestBody Racks rack) {
        Response<Racks> response = racksService.updateRack(rack);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Response<Racks>> deleteRack(@PathVariable String id) {
        Response<Racks> response = racksService.deleteRack(id);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/warehouse/{warehouseId}")
    public ResponseEntity<Response<List<Racks>>> getRacksByWarehouse(@PathVariable String warehouseId) {
        Response<List<Racks>> response = racksService.getRacksByWarehouse(warehouseId);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }
}