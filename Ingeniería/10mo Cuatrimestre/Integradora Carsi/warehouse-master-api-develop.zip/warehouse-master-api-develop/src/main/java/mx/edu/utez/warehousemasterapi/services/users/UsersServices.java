package mx.edu.utez.warehousemasterapi.services.users;

import mx.edu.utez.warehousemasterapi.entities.users.Users;
import mx.edu.utez.warehousemasterapi.entities.users.UsersRepository;
import mx.edu.utez.warehousemasterapi.enums.roles.Role;
import mx.edu.utez.warehousemasterapi.services.mailservice.MailService;
import mx.edu.utez.warehousemasterapi.utils.HtmlMessageRender;
import mx.edu.utez.warehousemasterapi.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Service
public class UsersServices {
    private final UsersRepository usersRepository;
    private final PasswordEncoder passwordEncoder;
    private final MailService mailService;
    private final HtmlMessageRender htmlMessageRender;

    @Autowired
    public UsersServices(UsersRepository usersRepository, PasswordEncoder passwordEncoder, MailService mailService, HtmlMessageRender htmlMessageRender) {
        this.usersRepository = usersRepository;
        this.passwordEncoder = passwordEncoder;
        this.mailService = mailService;
        this.htmlMessageRender = htmlMessageRender;
    }

    @Transactional(readOnly = true)
    public Response<List<Users>> getAllUsers() {
        List<Users> users = usersRepository.findAllByActiveOrderByLastModifiedDesc(true);
        return new Response<>(
                users,
                false,
                200,
                "ok!"
        );
    }

    @Transactional(readOnly = true)
    public Response<List<Users>> getAllUsersByRole(Role role) {
        List<Users> users = usersRepository.findAllByActiveAndRoleOrderByLastModifiedDesc(true, role);
        return new Response<>(
                users,
                false,
                200,
                "ok!"
        );
    }

    @Transactional(readOnly = true)
    public Response<Users> getUserById(String id) {
        Optional<Users> user = usersRepository.findById(id);
        return user.map(users -> new Response<>(
                users,
                false,
                200,
                "ok!"
        )).orElseGet(() -> new Response<>(
                null,
                true,
                404,
                "Not Found"
        ));
    }

    @Transactional(readOnly = true)
    public Response<Users> getUserByEmail(String email) {
        Optional<Users> user = usersRepository.findByEmail(email);
        return user.map(users -> new Response<>(
                users,
                false,
                200,
                "ok!"
        )).orElseGet(() -> new Response<>(
                null,
                true,
                404,
                "Not Found"
        ));
    }

    @Transactional(rollbackFor = {SQLException.class})
    public Response<Users> createUser(Users user) {
        user.setActive(true);
        user.setLastModified(new Timestamp(System.currentTimeMillis()));
        try {
            mailService.sendHtmlMessage(
                    user.getEmail(),
                    "Bienvenido a Warehouse Master",
                    htmlMessageRender.renderUser(user.getName(), user.getEmail(), user.getPassword())
            );
        } catch (Exception e) {
            return new Response<>(
                    null,
                    true,
                    500,
                    "Error al enviar el correo"
            );
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return new Response<>(
                usersRepository.save(user),
                false,
                200,
                "ok!"
        );
    }

    @Transactional(rollbackFor = {SQLException.class})
    public Response<Users> updateUser(Users user) {
        user.setLastModified(new Timestamp(System.currentTimeMillis()));
        Optional<Users> update = usersRepository.findById(user.getUid());
        if (update.isPresent()) {
            user.setPassword(update.get().getPassword());
            return new Response<>(
                    usersRepository.saveAndFlush(user),
                    false,
                    200,
                    "Updated!"
            );
        }
        return new Response<>(
                null,
                true,
                404,
                "Not Found"
        );
    }

    @Transactional(rollbackFor = {SQLException.class})
    public Response<Users> deleteUser(String uid) {
        Optional<Users> user = usersRepository.findById(uid);
        if (user.isPresent()) {
            usersRepository.delete(user.get());
            return new Response<>(
                    user.get(),
                    false,
                    200,
                    "Deleted!"
            );
        }
        return new Response<>(
                null,
                true,
                404,
                "Not Found"
        );
    }

    @Transactional(rollbackFor = {SQLException.class})
    public Response<Users> changeStatus(String uid) {
        Optional<Users> user = usersRepository.findById(uid);
        if (user.isPresent()) {
            user.get().setActive(!user.get().getActive());
            return new Response<>(
                    usersRepository.saveAndFlush(user.get()),
                    false,
                    200,
                    "Updated!"
            );
        }
        return new Response<>(
                null,
                true,
                400,
                "Not Found"
        );
    }

}
