package mx.edu.utez.warehousemasterapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseMasterApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
