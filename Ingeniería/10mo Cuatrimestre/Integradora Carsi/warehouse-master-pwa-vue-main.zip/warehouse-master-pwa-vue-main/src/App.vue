<script setup>
</script>

<template>
   <v-app style="background-color: #fafafa;">
    <div>
      <router-view/>
    </div>
   </v-app>
</template>
