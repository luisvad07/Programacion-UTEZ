<script setup lang="ts">

</script>

<template>
  <main>
    <TheWelcome />
  </main>
</template>
