import type { NextConfig } from "next";

/** @type {import('next').NextConfig} */
const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  rules: {
    "@typescript-eslint/no-explicit-any": "off", // Desactiva la regla para evitar errores con `any`
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  output: 'standalone', // Habilitar compilación standalone
};

export default nextConfig;
