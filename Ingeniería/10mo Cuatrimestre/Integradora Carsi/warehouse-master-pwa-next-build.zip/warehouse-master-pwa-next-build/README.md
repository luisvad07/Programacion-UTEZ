Proyecto Integradora 
10C IDyGS
