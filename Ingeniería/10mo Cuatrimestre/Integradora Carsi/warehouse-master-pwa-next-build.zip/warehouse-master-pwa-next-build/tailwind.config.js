/** @type {import('tailwindcss').Config} */
const withMT = require("@material-tailwind/react/utils/withMT");
module.exports = withMT({
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
 
    // Or if using `src` directory:
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
    "./node_modules/@material-tailwind/react/components/**/*.{js,ts,jsx,tsx}",
    "./node_modules/@material-tailwind/react/theme/components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        rosePrimary: '#BB5E7D', // Rosa
        deepMaroon: '#4B0019', // Marrón oscuro
        deepMaroonOpacityOff: '#4b0019cc', // Marrón oscuro para cuando no hay opacity
        softPinkBackground: '#E196AF', // Fondo suave rosado
        palePinkBackground: '#FBE8EE', // Fondo rosa muy claro
        deepRedAccent: '#701332', // Rojo acentuado
        errorColor: '#4B0019', // Rojo para errores
        lightGray: '#F0F4F8', // Blanco grisáceo
      },
    }
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
});