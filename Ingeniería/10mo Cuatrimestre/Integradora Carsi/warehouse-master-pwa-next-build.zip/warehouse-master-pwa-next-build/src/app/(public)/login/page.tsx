'use client'
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from '@/contexts/AuthContext';

export default function Login() {
    const [usuario, setUsuario] = useState("");
    const [contrasena, setContrasena] = useState("");
    const [mfacode, setMfaCode] = useState("");
    const [mostrarContrasena, setMostrarContrasena] = useState(false);
    //const router = useRouter();
    const { login, userNeedsMfa } = useAuth();

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const isValidEmail = emailRegex.test(usuario);
        const isValidPassword = contrasena.length >= 1;

        if (isValidEmail && isValidPassword) {
            try {
                if (userNeedsMfa) {
                    await login(usuario, contrasena, mfacode);
                } else {
                    await login(usuario, contrasena);
                }
            } catch (error) {
                console.error(error);
                alert('Credenciales inválidas');
            }
        } else {
            if (!isValidEmail) {
                alert("Correo electrónico inválido");
            }
            if (!isValidPassword) {
                alert("La contraseña debe tener al menos 8 caracteres");
            }
        }
    };

    // const toggleMostrarContrasena = () => {
    //     setMostrarContrasena(!mostrarContrasena);
    // };

    return (
        <>
            {/*
        This example requires updating your template:

        ```
        <html class="h-full bg-gray-50">
        <body class="h-full">
        ```
      */}
            <div className="min-h-full flex flex-col justify-center py-12 sm:px-6 lg:px-8">


                <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">

                    <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
                        <div className="sm:mx-auto sm:w-full sm:max-w-md">
                            {/* <img
                                className="mx-auto h-12 w-auto"
                                src="/icon.svg"
                                alt="Workflow"
                            /> */}
                            <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">Inicio de Sesión</h2>
                            <p className="mt-2 text-center text-sm text-deepMaroonOpacityOff">
                                Warehouse Master
                            </p>
                        </div>
                        <form className="space-y-6" onSubmit={handleSubmit}>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                                    Correo electrónico
                                </label>
                                <div className="mt-1">
                                    <input
                                        id="email"
                                        name="email"
                                        type="email"
                                        onChange={(e) => setUsuario(e.target.value)}
                                        autoComplete="email"
                                        required
                                        className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-deepMaroonOpacityOff focus:border-deepMaroonOpacityOff sm:text-sm"
                                    />
                                </div>
                            </div>

                            <div>
                                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                                    Contraseña
                                </label>
                                <div className="mt-1">
                                    <input
                                        id="password"
                                        name="password"
                                        type="password"
                                        onChange={(e) => setContrasena(e.target.value)}
                                        autoComplete="current-password"
                                        required
                                        className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-deepMaroonOpacityOff focus:border-deepMaroonOpacityOff sm:text-sm"
                                    />
                                </div>
                            </div>

                            {userNeedsMfa && (
                                <div>
                                    <label htmlFor="mfa" className="block text-sm font-medium text-gray-700">
                                        Código de Autenticación MFA
                                    </label>
                                    <div className="mt-1">
                                        <input
                                            id="mfa"
                                            name="mfa"
                                            type="number"
                                            maxLength={6}
                                            minLength={6}
                                            onChange={(e) => setMfaCode(e.target.value)}
                                            required
                                            className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-deepMaroonOpacityOff focus:border-deepMaroonOpacityOff sm:text-sm"
                                        />
                                    </div>
                                </div>
                            )}

                            <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                    <input
                                        id="remember-me"
                                        name="remember-me"
                                        type="checkbox"
                                        className="h-4 w-4 text-deepMaroonOpacityOff focus:ring-deepMaroonOpacityOff border-gray-300 rounded"
                                    />
                                    <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
                                        Continuar conectado
                                    </label>
                                </div>

                                <div className="text-sm">
                                    <a href="#" className="font-medium text-deepMaroonOpacityOff hover:text-deepMaroon">
                                        ¿Olvidaste tu contraseña?
                                    </a>
                                </div>
                            </div>

                            <div>
                                <button
                                    type="submit"
                                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-deepMaroonOpacityOff hover:bg-deepMaroon focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-deepMaroon"
                                >
                                    Iniciar Sesión
                                </button>
                            </div>
                        </form>

                        <div className="mt-6">

                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}