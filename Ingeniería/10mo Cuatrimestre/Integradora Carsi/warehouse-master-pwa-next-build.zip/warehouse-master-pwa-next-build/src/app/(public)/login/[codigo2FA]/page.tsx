"use client";

import { useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';
import AlertComponent from '@/components/common/AlertComponent';

export default function CodePage() {
  const [inputCode, setInputCode] = useState('');
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertType, setAlertType] = useState<'warning' | 'info' | 'success'>('warning');
  const router = useRouter();
  const searchParams = useSearchParams();
  //const codigo2FA = searchParams.get('codigo2FA'); // Captura el código 2FA de la URL

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();

    if (inputCode === inputCode) { // Asegúrate de comparar con el código correcto
      setAlertType('success');
      setAlertMessage('Código correcto');
      setShowAlert(true);
      setTimeout(() => {
        router.push('/dashboard');
      }, 2000); // Redirigir después de 2 segundos
    } else {
      setAlertType('warning');
      setAlertMessage('Código incorrecto. Intenta de nuevo.');
      setShowAlert(true);
    }
  };

  const handleCloseAlert = () => {
    setShowAlert(false);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-blue-700">
      <div className="rounded-xl bg-white p-8 shadow-md w-[500px]">
        <h1 className="text-2xl font-bold text-blue-500 text-center">Código de Verificación</h1>
        <form onSubmit={handleVerifyCode}>
          <div className="mb-4">
            <label className="block text-gray-700 font-bold mb-2" htmlFor="code">
              Ingresa el código que recibiste
            </label>
            <input
              type="text"
              id="code"
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              value={inputCode}
              onChange={(e) => setInputCode(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full"
          >
            Verificar Código
          </button>
        </form>
      </div>

      {showAlert && (
        <AlertComponent
          title={alertType === 'success' ? 'Éxito' : 'Advertencia'}
          description={alertMessage}
          type={alertType}
          onAccept={handleCloseAlert}
          onCancel={handleCloseAlert}
        />
      )}
    </div>
  );
}
