'use client'

import React, { useState, useEffect } from 'react';
import { fetchClient } from "@/lib/utils/fetchClient";
import { DynamicTable, TableColumn } from '@/components/layout/admin/DynamicTable';
import AlertComponent from "@/components/common/AlertComponent";
import moment from 'moment';
import MovementForm from "@/components/common/MovementForm";
import { FaArrowCircleDown, FaArrowCircleUp, FaExchangeAlt, FaAdjust, FaTimesCircle, FaUserTimes, FaSignOutAlt } from 'react-icons/fa';

const statusConfig = {
    UNASSIGNED_ENTRY: { icon: <FaUserTimes />, color: 'text-blue-500', backgroundColor: 'bg-blue-400', translation: 'Entrada No Asignada' },
    UNASSIGNED_EXIT: { icon: <FaUserTimes />, color: 'text-red-500', backgroundColor: 'bg-red-400', translation: 'Salida No Asignada' },
    UNASSIGNED_TRANSFER: { icon: <FaExchangeAlt />, color: 'text-yellow-500', backgroundColor: 'bg-yellow-400', translation: 'Transferencia No Asignada' },
    UNASSIGNED_ADJUSTMENT: { icon: <FaAdjust />, color: 'text-green-500', backgroundColor: 'bg-green-400', translation: 'Ajuste No Asignado' },
    ASSIGNED_ENTRY: { icon: <FaArrowCircleDown />, color: 'text-blue-700', backgroundColor: 'bg-blue-400', translation: 'Entrada Asignada' },
    ASSIGNED_EXIT: { icon: <FaArrowCircleUp />, color: 'text-red-700', backgroundColor: 'bg-red-400', translation: 'Salida Asignada' },
    ASSIGNED_TRANSFER: { icon: <FaExchangeAlt />, color: 'text-yellow-700', backgroundColor: 'bg-yellow-400', translation: 'Transferencia Asignada' },
    ASSIGNED_ADJUSTMENT: { icon: <FaAdjust />, color: 'text-green-700', backgroundColor: 'bg-green-400', translation: 'Ajuste Asignado' },
    PENDING_ENTRY: { icon: <FaArrowCircleDown />, color: 'text-blue-300', backgroundColor: 'bg-blue-400', translation: 'Entrada Pendiente' },
    PENDING_EXIT: { icon: <FaArrowCircleUp />, color: 'text-red-300', backgroundColor: 'bg-red-400', translation: 'Salida Pendiente' },
    PENDING_TRANSFER: { icon: <FaExchangeAlt />, color: 'text-yellow-300', backgroundColor: 'bg-yellow-400', translation: 'Transferencia Pendiente' },
    PENDING_ADJUSTMENT: { icon: <FaAdjust />, color: 'text-green-300', backgroundColor: 'bg-green-400', translation: 'Ajuste Pendiente' },
    ENTRY: { icon: <FaArrowCircleDown />, color: 'text-blue-900', backgroundColor: 'bg-blue-400', translation: 'Entrada' },
    EXIT: { icon: <FaArrowCircleUp />, color: 'text-red-900', backgroundColor: 'bg-red-400', translation: 'Salida' },
    TRANSFER: { icon: <FaExchangeAlt />, color: 'text-yellow-900', backgroundColor: 'bg-yellow-400', translation: 'Transferencia' },
    ADJUSTMENT: { icon: <FaAdjust />, color: 'text-green-900', backgroundColor: 'bg-green-400', translation: 'Ajuste' },
    CANCELLED: { icon: <FaTimesCircle />, color: 'text-gray-500', backgroundColor: 'bg-gray-400', translation: 'Cancelado' },
};

const statusConfigKeys = {
    UNASSIGNED_EXIT: {icon:<FaUserTimes />},
    ENTRY: { icon: <FaArrowCircleDown /> },
    EXIT: { icon: <FaSignOutAlt /> },
    TRANSFER: { icon: <FaExchangeAlt /> },
};

const MovementPage = () => {
    const [isEdit, setIsEdit] = useState(false);
    const [isCreate, setIsCreate] = useState(false);
    const [editData, setEditData] = useState<any | null>(null);
    const [dataTable, setData] = useState<any[]>([]);
    const [showAlert, setShowAlert] = useState(false);
    const [movementToDelete, setMovementToDelete] = useState<any | null>(null);

    const getMovements = async () => {
        return await fetchClient({ ruta: `/movements/`, metodo: "GET" });
    };

    const getMovementById = async (id: string) => {
        return await fetchClient({ ruta: `/movements/${id}`, metodo: "GET" });
    };

    const createMovement = async (data: any) => {
        return await fetchClient({ ruta: `/movements/`, metodo: "POST", datos: data });
    };

    const updateMovement = async (data: any) => {
        return await fetchClient({ ruta: `/movements/`, metodo: "PUT", datos: data });
    };

    const deleteMovement = async (id: string) => {
        return await fetchClient({ ruta: `/movements/${id}`, metodo: "DELETE" });
    };

    const unassignMovement = async (movementId: string) => {
        return await fetchClient({ ruta: `/movements/unassign/${movementId}`, metodo: "PUT" });
    };

    const pendingMovement = async (data: any) => {
        return await fetchClient({ ruta: `/movements/pending/`, metodo: "PUT", datos: data });
    };

    const cancelMovement = async (movementId: string) => {
        return await fetchClient({ ruta: `/movements/cancel/${movementId}`, metodo: "PUT" });
    };

    const assignMovement = async (movementId: string, userId: string) => {
        return await fetchClient({ ruta: `/movements/assign/${movementId}/${userId}`, metodo: "PUT" });
    };

    const approveMovement = async (movementId: string) => {
        return await fetchClient({ ruta: `/movements/approved/${movementId}`, metodo: "PUT" });
    };

    const columns: TableColumn<any>[] = [
        {
            key: "status", label: "Estado", width: "50px", sortable: true, render: (status) => {
                const config = statusConfig[status.status] || {};
                const statusName = statusConfig[status.status]?.translation || status.status;
                return (
                    <div className={`flex items-center ${config.color} relative group`}>
                        <span className='cursor-pointer transform transition-transform duration-300 hover:scale-125'>
                            {config.icon}
                        </span>
                        <span className={`ml-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 absolute left-0 bottom-full transform -translate-y-1/2 p-1 rounded shadow-lg w-[200px] text-center ${config.backgroundColor} text-white`}>
                            {statusName}
                        </span>
                    </div>
                );
            }
        },
        { key: "user", label: "Creado Por", sortable: true, render: (value) => value ? value.user.name : "Sin usuario" },
        { key: "assignedUser", label: "Usuario Asignado", sortable: true, render: (value) => value.assignedUser ? value.assignedUser.name : "Sin usuario" },
        { key: "lastModified", label: "Última Modificación", sortable: true, render: (value) => moment(value).format("DD/MM/YYYY") },
        { key: "actions", label: "Acciones", width: "100px" },
    ];

    const handleEdit = async (data: any) => {
        try {
            data.uid = editData.uid;
            const updatedItem = await updateMovement(data);
            if (updatedItem) {
                const newData = await getMovements();
                setData(newData as any[]);
                setIsEdit(false);
                setEditData(null);
            }
        } catch (error) {
            console.error("Error editing item", error);
        }
    };

    const handleAdd = async (data: any) => {
        try {
            const newItem = await createMovement(data);
            if (newItem) {
                const newData = await getMovements();
                setData(newData as any[]);
                setIsCreate(false);
            }
        } catch (error) {
            console.error("Error adding new item", error);
        }
    };

    const handleDelete = async (itemToDelete) => {
        setMovementToDelete(itemToDelete);
        setShowAlert(true);
    }

    const confirmDelete = async () => {
        if (movementToDelete) {
            try {
                await deleteMovement(movementToDelete.uid);
                setData((prevData) => prevData.filter(item => item.uid !== movementToDelete.uid));
                setMovementToDelete(null);
                setShowAlert(false);
            } catch (error) {
                console.error("Error deleting item", error);
            }
        }
    }

    const cancelDelete = () => {
        setMovementToDelete(null);
        setShowAlert(false);
    }

    const handleChangeStatus = (item: any, newStatus: Boolean) => {
        console.log("Status to " + newStatus);
    };

    const getData = async () => {
        try {
            const data = await getMovements();
            setData(data as any[]);
        } catch (error) {
            console.error("Error fetching data", error);
        }
    };

    useEffect(() => {
        const fetchData = async () => {
            await getData();
        };
        fetchData();
    }, []);

    const tabs = [
        { label: 'Todos', value: 'all' },
        ...Object.keys(statusConfigKeys).map(status => ({
            label: statusConfigKeys[status].icon,
            value: status,
        }))
    ];

    return (
        <div className='h-full w-full'>
            {dataTable ? <DynamicTable
                columns={columns}
                data={dataTable}
                paginationOptions={{
                    pageSize: 7,
                    initialPage: 1
                }}
                tabs={tabs}
                title="Movimientos"
                subtitle="Lista de movimientos"
                onEdit={(data) => {
                    setIsEdit(true);
                    setEditData({ ...data });
                }}
                onAdd={() => setIsCreate(true)}
                onDelete={(id) => handleDelete(id)}
                onStatusChange={handleChangeStatus}
                isEnabledDelete={false}
            /> : <div>No data available</div>}

            {isCreate && <MovementForm
                onSave={handleAdd}
                onClose={() => setIsCreate(false)}
            />}

            {isEdit && editData && <MovementForm
                initialData={editData}
                onSave={handleEdit}
                onClose={() => setIsEdit(false)}
            />}

            {showAlert && (
                <AlertComponent
                    title="Confirm Deletion"
                    description={`Are you sure you want to delete this movement? This action cannot be undone.`}
                    type="warning"
                    onAccept={confirmDelete}
                    onCancel={cancelDelete}
                />
            )}
        </div>
    );
}

export default MovementPage;