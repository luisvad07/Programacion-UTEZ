export default function Pruebas() {
    return (
        <div>
            Hola desde pruebas
        </div>
    );
}