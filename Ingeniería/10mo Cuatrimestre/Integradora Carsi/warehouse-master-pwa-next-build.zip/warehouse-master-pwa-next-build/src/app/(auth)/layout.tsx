'use client'
import { useAuth } from '@/contexts/AuthContext'
import React from 'react'
import { AdminSidebar } from '@/components/layout/admin/AdminSidebar'
import { SuperAdminSidebar } from '@/components/layout/admin/SuperAdminSidebar'
import { CustomerSidebar } from '@/components/layout/customer/CustomerSidebar'
import { Navbar } from '@/components/layout/Navbar'
import { Spinner } from "@material-tailwind/react"
import AlertTag from '@/components/common/AlertTag'

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { loading } = useAuth();
  let userL = null;
if (typeof window !== "undefined") {
    userL = localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")!) : null;
}
 // const router = useRouter()
  //const pathname = usePathname()

  //Hola compañeros del front, si quieren meterse a rutas protegidas por el login, comenten esta linea, los quiero, att: su scrum favorito

  // useEffect(() => {
  //   if (!loading && !user) {
  //     router.push('/login')
  //   }
  // }, [loading, user, router])


  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Spinner className="h-12 w-12" />
      </div>
    )
  }
  const Sidebars = {
    ADMIN: AdminSidebar,
    SUPER_ADMIN: SuperAdminSidebar,
    default: CustomerSidebar
  }

  const Sidebar = userL?.role ? Sidebars[userL.role] : Sidebars.default;

  return (
    <div className="flex min-h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <Navbar />
        <main className="flex-1 h-[93vh] max-h-[93vh] w-[calc(100vw-20rem)] relative">
          <AlertTag type={'success'} />
          <AlertTag type={'danger'} />
          {children}
        </main>
      </div>
    </div>
  )
}