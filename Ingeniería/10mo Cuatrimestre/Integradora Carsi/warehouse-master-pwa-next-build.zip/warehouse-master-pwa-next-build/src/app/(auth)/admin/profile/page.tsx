'use client';

import React, { useEffect, useState } from 'react';
import { Card, CardBody, Typography, Button, Chip } from '@material-tailwind/react';
import { fetchClient } from '@/lib/utils/fetchClient';
import { getUserData, setUserData } from "@/lib/utils/auth";

const Profile = () => {
    const user = getUserData();
    const [mfaImage, setMfaImage] = useState<string | null>(null);
    const [mfaKey, setMfaKey] = useState<string | null>(null);
    const [userNeedsMfa, setUserNeedsMfa] = useState(user.mfaEnabled);

    const activateMfa = async () => {
        try {
            const response: { data: { image: string, key: string } } = await fetchClient({
                ruta: '/mfa/activate',
                metodo: 'POST'
            });
            setMfaImage(response.data.image);
            setMfaKey(response.data.key);
        } catch (error) {
            console.error('Error activando MFA:', error);
        }
    };

    const deactivateMfa = async () => {
        try {
            await fetchClient({
                ruta: '/mfa/deactivate',
                metodo: 'DELETE'
            });
            setUserNeedsMfa(false);
            setMfaImage(null);
            setMfaKey(null);
        } catch (error) {
            console.error('Error desactivando MFA:', error);
        }
    };

    const getUser = async () => {
        try {
            const response: { data: { mfaEnabled: boolean } } = await fetchClient({
                ruta: `/users/get-user-uid/${user.uid}`,
                metodo: 'GET'
            });
            setUserNeedsMfa(response.data.mfaEnabled);
        } catch (error) {
            console.error('Error obteniendo usuario:', error);
        }
    };

    useEffect(() => {
        getUser();
    }, []);

    useEffect(() => {
        user.mfaEnabled = userNeedsMfa;
        setUserData(user);
    }, [userNeedsMfa]);

    return user ? (
        <div className="flex justify-center items-center h-full">
            <Card className="w-full max-w-md" placeholder={undefined}>
                <CardBody placeholder={undefined}>
                    <div className="mb-4">
                        <Typography variant="h6" placeholder={undefined}>Nombre:</Typography>
                        <Typography placeholder={undefined}>{user.name}</Typography>
                    </div>
                    <div className="mb-4">
                        <Typography variant="h6" placeholder={undefined}>Correo Electrónico:</Typography>
                        <Typography placeholder={undefined}>{user.email}</Typography>
                    </div>
                    <div className="mb-4">
                        <Typography variant="h6" placeholder={undefined}>Rol:</Typography>
                        <Typography placeholder={undefined}>{user.role}</Typography>
                    </div>
                    <div className="mb-4">
                        <Typography variant="h6" placeholder={undefined}>Estado de MFA:</Typography>
                        <Chip size="sm" variant="gradient" color={userNeedsMfa ? 'green' : 'red'} value={userNeedsMfa ? 'Habilitado' : 'Deshabilitado'} />
                    </div>
                    {userNeedsMfa && mfaImage && (
                        <div className="mb-4">
                            <div className="flex justify-center mb-4">
                                <img src={mfaImage} alt="Código QR de MFA" className="mb-2" />
                            </div>
                            <Typography variant="h6" placeholder={undefined}>Clave:</Typography>
                            <Typography placeholder={undefined}>{mfaKey}</Typography>
                            <Typography placeholder={undefined}>Esta información no se mostrará nuevamente. Guarda tu clave MFA en un lugar seguro. La necesitarás para recuperar tu cuenta si pierdes tu dispositivo.</Typography>
                        </div>
                    )}
                    <Button color={userNeedsMfa ? 'red' : 'green'} onClick={userNeedsMfa ? deactivateMfa : activateMfa} placeholder={undefined}>
                        {userNeedsMfa ? 'Deshabilitar MFA' : 'Habilitar MFA'}
                    </Button>
                </CardBody>
            </Card>
        </div>
    ) : <p>No hay datos</p>;
};

export default Profile;