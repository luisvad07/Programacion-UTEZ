'use client'

import { fetchClient } from "@/lib/utils/fetchClient";
import CreateModal from '@/components/common/CreateModal';
import EditModal from '@/components/common/EditModal';
import { DynamicTable, TableColumn } from '@/components/layout/admin/DynamicTable';
import React, { useEffect, useState } from 'react';
import AlertComponent from "@/components/common/AlertComponent";
import moment from 'moment';
import AlertTag from "@/components/common/AlertTag";



// Columnas de la tabla
const columns: TableColumn<any>[] = [
  { key: "name", label: "Nombre", sortable: true },
  { key: "description", label: "Descripción", sortable: true },
  { key: "active", label: "Activo", sortable: false, width: "75px" },
  { key: "lastModified", label: "Última Modificación", sortable: true, render: (value) => moment(value).format("DD/MM/YYYY") },
  { key: "actions", label: "Acciones", width: "100px" }, // Columna para acciones como editar
];


// Tabs de ejemplo
const tabs = [
  { label: "Todos", value: "all" },
  { label: "Activo", value: "active" },
  { label: "Inactivo", value: "inactive" },
];

const categoryInputsEdit = [
  {
    label: "Nombre",
    name: "name",
    value: "",
    type: "text",
    onChange: (name: string, value: any) => {
      console.log(`Input ${name} changed to ${value}`);
    },
  },
  {
    label: "Descripción",
    name: "description",
    value: "",
    type: "text",
    onChange: (name: string, value: any) => {
      console.log(`Input ${name} changed to ${value}`);
    },
  },
];

const categoryInputsCreate = [
  {
    name: "name",
    label: "Nombre",
    value: "",
    type: "text",
    onChange: (name: string, value: any) => {
      console.log(`Input ${name} changed to ${value}`);
    },
  },
  {
    name: "description",
    label: "Descripción",
    value: "",
    type: "text",
    onChange: (name: string, value: any) => {
      console.log(`Input ${name} changed to ${value}`);
    },
  },
];

export default function CategoryPage() {
  const [isEdit, setIsEdit] = useState(false);
  const [isCreate, setIsCreate] = useState(false);
  const [editData, setEditData] = useState<any | null>(null);
  const [dataTable, setData] = useState<any[]>([]);
  const [showAlert, setShowAlert] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<any | null>(null);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);
  const [alertType, setAlertType] = useState(null);

  // Función para editar
  const handleEdit = async (data: any) => {
    console.log("Edit item", data);
    try {
      const updatedItem = await fetchClient({ ruta: `/categories/`, metodo: "PUT", datos: data });
      if (updatedItem) {
        setData((prevData) => prevData.map(item => item.uid === data.uid ? updatedItem : item));
        setIsEdit(false);
        setEditData(null);
      }
    } catch (error) {
      console.error("Error editing item", error);
    }
  };

  // Función para añadir
  const handleAdd = async (data: any) => {
    console.log("Add new item", data);
    try {
      const newItem = await fetchClient({ ruta: "/categories/", metodo: "POST", datos: data });
      if (newItem) {
        setData((prevData) => [...prevData, newItem]);
        setIsCreate(false);
      }
    } catch (error) {
      console.error("Error adding new item", error);
    }
  };

  // Función para eliminar
  const handleDelete = async (itemToDelete: any) => {
    setItemToDelete(itemToDelete);
    setShowAlert(true);
  };

  const confirmDelete = async () => {
    if (itemToDelete) {
      try {await fetchClient({ ruta: `/categories/${itemToDelete.uid}`, metodo: "DELETE" });
        const data = await fetchClient({ ruta: "/categories/", metodo: "GET" });
        setData(data as any[]);
        setItemToDelete(null);
        setShowAlert(false);
        
      } catch (error) {
        setAlertType("danger");
        setShowDeleteAlert(true);
        setTimeout(() => {
          setShowDeleteAlert(false);
        }, 2000);
        console.error("Error deleting item", error);
      }
    }
  };

  const cancelDelete = () => {
    setItemToDelete(null);
    setShowAlert(false);
  };

  const handleChangeStatus = (item: any, newStatus: Boolean) => {
    console.log("Status to " + newStatus);
  };

  const getData = async () => {
    console.log("Fetching data...");
    try {
      const data = await fetchClient({ ruta: "/categories/", metodo: "GET" });
      console.log(data);
      setData(data as any[]);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    const llamarLaData = async () => {
      await getData();
    };
    llamarLaData();
  }, []);

  return (
    <div className='h-full w-full relative'>
      {dataTable ? <DynamicTable
        columns={columns}
        data={dataTable}
        paginationOptions={{
          pageSize: 7,
          initialPage: 1
        }}
        tabs={tabs}
        title="Categorías"
        subtitle="Gestión de categorías"
        onEdit={(data) => {
          setIsEdit(true);
          setEditData({ ...data });
        }}
        onAdd={() => setIsCreate(true)}
        onDelete={(item) => handleDelete(item)}
        onStatusChange={handleChangeStatus}
      /> : <div>No hay datos</div>}

      {isCreate && <CreateModal
        title="Crear Categoría"
        inputs={categoryInputsCreate}
        onClose={() => setIsCreate(false)}
        onSave={(data) => handleAdd(data)}
      />}

      {isEdit && editData && <EditModal
        title="Editar Categoría"
        initialData={editData}
        inputs={categoryInputsEdit}
        onClose={() => setIsEdit(false)}
        onSave={(data) => handleEdit(data as any)}
      />}

      {showAlert && (
        <AlertComponent
          title="Confirm Deletion"
          description={`Are you sure you want to delete "${itemToDelete?.name}"? This action cannot be undone.`}
          type="warning"
          onAccept={confirmDelete}
          onCancel={cancelDelete}
        />
      )}

      {showDeleteAlert && <AlertTag type={alertType} />}
    </div>
  );
}