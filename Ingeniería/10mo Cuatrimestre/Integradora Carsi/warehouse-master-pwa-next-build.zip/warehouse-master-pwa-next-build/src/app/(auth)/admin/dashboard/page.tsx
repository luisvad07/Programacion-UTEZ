'use client'
import {
  Card,
  CardBody,
  Typography,
  Button,
} from "@material-tailwind/react"

export default function AdminDashboard() {

  // if (!user || user.role !== 'ADMIN') {
  //   return null
  // }

  return (
    <div className="space-y-6">
      <Typography variant="h3" color="blue-gray" placeholder={undefined} onPointerEnterCapture={() => {}} onPointerLeaveCapture={undefined}>
        Dashboard de Administrador
      </Typography>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card placeholder={undefined} onPointerEnterCapture={() => {}} onPointerLeaveCapture={undefined}>
          <CardBody placeholder={undefined} onPointerEnterCapture={() => {}} onPointerLeaveCapture={undefined}>
            <Typography variant="h5" color="blue-gray" className="mb-2" placeholder={undefined} onPointerEnterCapture={() => {}} onPointerLeaveCapture={undefined}>
              Usuarios Activos
            </Typography>
            <Typography placeholder={undefined} onPointerEnterCapture={() => {}} onPointerLeaveCapture={undefined}>
              125 usuarios
            </Typography>
          </CardBody>
        </Card>
        
        {/* Agrega más cards según necesites */}
      </div>
    </div>
  )
}