'use client';
import React, { useEffect, useState } from 'react';
import { Card, CardBody, CardHeader, Typography } from '@material-tailwind/react';
import {
  FaUserTimes,
  FaWarehouse,
  FaBox,
  FaTruckMoving,
  FaExclamationTriangle,
} from 'react-icons/fa';
import { fetchClient } from '@/lib/utils/fetchClient';

const Dashboard: React.FC = () => {
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await fetchClient({ ruta: '/dashboard/', metodo: 'GET' });
        setDashboardData(data);
      } catch (err: any) {
        console.error('Error al obtener datos del dashboard', err);
        setError(err.message || 'Ocurrió un error.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  if (isLoading) {
    return (
        <div className="flex justify-center items-center h-screen">
          <Typography variant="h5">Cargando...</Typography>
        </div>
    );
  }

  if (error) {
    return (
        <div className="flex justify-center items-center h-screen">
          <Typography variant="h5" color="red">
            {error}
          </Typography>
        </div>
    );
  }

  if (!dashboardData) {
    return (
        <div className="flex justify-center items-center h-screen">
          <Typography variant="h5" color="red">
            No hay datos disponibles.
          </Typography>
        </div>
    );
  }

  return (
      <div className="p-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          <Card className="shadow-md">
            <CardHeader color="blue" className="text-center flex items-center justify-center py-4">
              <FaUserTimes className="mr-2 text-2xl" />
              <Typography variant="h6" className="font-medium">Usuarios Activos</Typography>
            </CardHeader>
            <CardBody className="text-center py-6">
              <Typography variant="h3" className="font-bold">{dashboardData.activeUsers}</Typography>
            </CardBody>
          </Card>

          <Card className="shadow-md">
            <CardHeader color="green" className="text-center flex items-center justify-center py-4">
              <FaWarehouse className="mr-2 text-2xl" />
              <Typography variant="h6" className="font-medium">Almacenes Activos</Typography>
            </CardHeader>
            <CardBody className="text-center py-6">
              <Typography variant="h3" className="font-bold">{dashboardData.activeWarehouses}</Typography>
            </CardBody>
          </Card>

          <Card className="shadow-md">
            <CardHeader color="red" className="text-center flex items-center justify-center py-4">
              <FaBox className="mr-2 text-2xl" />
              <Typography variant="h6" className="font-medium">Productos Activos</Typography>
            </CardHeader>
            <CardBody className="text-center py-6">
              <Typography variant="h3" className="font-bold">{dashboardData.activeProducts}</Typography>
            </CardBody>
          </Card>

          <Card className="shadow-md">
            <CardHeader color="purple" className="text-center flex items-center justify-center py-4">
              <FaTruckMoving className="mr-2 text-2xl" />
              <Typography variant="h6" className="font-medium">Movimientos Activos</Typography>
            </CardHeader>
            <CardBody className="text-center py-6">
              <Typography variant="h3" className="font-bold">{dashboardData.activeMovements}</Typography>
            </CardBody>
          </Card>
        </div>

        <div className="mt-12">
          <Typography variant="h5" className="mb-6 font-bold flex items-center">
            <FaExclamationTriangle className="mr-2 text-2xl text-yellow-500" />
            Productos por Vencer
          </Typography>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {dashboardData.productsToExpire.map((product: any) => (
                <Card key={product.uid} className="shadow-md">
                  <CardHeader color="orange" className="text-center py-4"> {/* Added padding */}
                    <Typography variant="h6" className="font-medium">{product.name}</Typography>
                  </CardHeader>
                  <CardBody className="py-6">
                    <Typography variant="body1">Descripción: {product.description}</Typography>
                    <Typography variant="body1">Precio: ${product.price}</Typography>
                    <Typography variant="body1">Fecha de Vencimiento: {new Date(product.expirationDate).toLocaleDateString()}</Typography>
                    <Typography variant="body1">Stock: {product.stock}</Typography>
                  </CardBody>
                </Card>
            ))}
          </div>
        </div>
      </div>
  );
};

export default Dashboard;