'use client'

import {fetchClient} from "@/lib/utils/fetchClient";
import CreateModal from '@/components/common/CreateModal';
import {DynamicTable, TableColumn} from '@/components/layout/admin/DynamicTable';
import moment from 'moment';
import React, {useEffect, useState} from 'react';
import AlertComponent from "@/components/common/AlertComponent";

// Columnas de la tabla
const columns: TableColumn<any>[] = [
    { key: "rackNumber", label: "Número de Rack", sortable: true },
    { key: "capacity", label: "Capacidad", sortable: true },
    { key: "description", label: "Descripción", sortable: true },
    { key: "maxFloor", label: "Piso Máximo", sortable: true },
    { key: "warehouse", label: "Almacén", sortable: true, render: (value) => value.warehouse ? value.warehouse.name : "Sin almacén" },
    { key: "active", label: "Activo", sortable: false, width: "75px" },
    { key: "lastModified", label: "Última Modificación", sortable: true, render: (value) => moment(value).format("DD/MM/YYYY") },
    { key: "actions", label: "Acciones", width: "100px" }, // Columna para acciones como editar
];

// Configuración de paginación
const paginationOptions = {
    pageSize: 2,
    initialPage: 1,
};

// Tabs de ejemplo
const tabs = [
    { label: "Todos", value: "all" },
    { label: "Activo", value: "active" },
    { label: "Inactivo", value: "inactive" },
];

export default function RackPage() {
    const [isEdit, setIsEdit] = useState(false);
    const [isCreate, setIsCreate] = useState(false);
    const [editData, setEditData] = useState<any | null>(null);
    const [dataTable, setData] = useState<any[]>([]);
    const [warehouseData, setWarehouseData] = useState<any[]>([]);
    const [showAlert, setShowAlert] = useState(false);
    const [rackToDelete, setRackToDelete] = useState<any | null>(null);

    const rackInputsCreate = [
    {
        name: "rackNumber",
        label: "Número de Rack",
        value: "",
        type: "text",
        onChange: (name: string, value: any) => {
            console.log(`Input ${name} changed to ${value}`);
        },
    },
    {
        name: "capacity",
        label: "Capacidad",
        value: "",
        type: "number",
        onChange: (name: string, value: any) => {
            console.log(`Input ${name} changed to ${value}`);
        },
    },
    {
        name: "description",
        label: "Descripción",
        value: "",
        type: "text",
        onChange: (name: string, value: any) => {
            console.log(`Input ${name} changed to ${value}`);
        },
    },
    {
        name: "maxFloor",
        label: "Piso Máximo",
        value: "",
        type: "number",
        onChange: (name: string, value: any) => {
            console.log(`Input ${name} changed to ${value}`);
        },
    },
    {
        name: "warehouse",
        label: "Almacén",
        value: "",
        type: "select",
        valuesToSelect: warehouseData,
        onChange: (name: string, value: any) => {
            console.log(`Input ${name} changed to ${value}`);
        },
    }
];

const rackInputsEdit = [
    {
        name: "rackNumber",
        label: "Número de Rack",
        value: editData?.rackNumber,
        type: "text",
        onChange: (name: string, value: any) => {
            console.log(`Input ${name} changed to ${value}`);
        },
    },
    {
        name: "capacity",
        label: "Capacidad",
        value: editData?.capacity,
        type: "number",
        onChange: (name: string, value: any) => {
            console.log(`Input ${name} changed to ${value}`);
        },
    },
    {
        name: "description",
        label: "Descripción",
        value: editData?.description,
        type: "text",
        onChange: (name: string, value: any) => {
            console.log(`Input ${name} changed to ${value}`);
        },
    },
    {
        name: "maxFloor",
        label: "Piso Máximo",
        value: editData?.maxFloor,
        type: "number",
        onChange: (name: string, value: any) => {
            console.log(`Input ${name} changed to ${value}`);
        },
    },
    {
        name: "warehouse",
        label: "Almacén",
        value: editData?.warehouse,
        type: "select",
        valuesToSelect: warehouseData,
        onChange: (name: string, value: any) => {
            console.log(`Input ${name} changed to ${value}`);
        },
    }
];

    // Función para editar
    const handleEdit = async (data: any) => {
        data.uid = editData.uid;
        data.active = editData.active;

        try {
            const updatedItem = await fetchClient({ruta: `/racks/`, metodo: "PUT", datos: data});
            if (updatedItem) {
                const updatedData = await fetchClient({ruta: "/racks/", metodo: "GET"});
                setData(updatedData as any[]);
                setIsEdit(false);
                setEditData(null);
            }
        } catch (error) {
            console.error("Error editing item", error);
        }
    };

    // Función para añadir
    const handleAdd = async (data: any) => {
        try {
            const newItem = await fetchClient({ruta: "/racks/", metodo: "POST", datos: data});
            if (newItem) {
                setData((prevData) => [...prevData, newItem]);
                setIsCreate(false);
            }
        } catch (error) {
            console.error("Error adding new item", error);
        }
    };

    const handleDelete = async (itemToDelete) => {
        setRackToDelete(itemToDelete);
        setShowAlert(true);
    }

    const confirmDelete = async () => {
        if (rackToDelete) {
            try {
                await fetchClient({ruta: `/racks/${rackToDelete.uid}`, metodo: "DELETE"});
                setData((prevData) => prevData.filter(item => item.uid !== rackToDelete.uid));
                setRackToDelete(null);
                setShowAlert(false);
            } catch (error) {
                console.error("Error deleting item", error);
            }
        }
    }

    const cancelDelete = () => {
        setRackToDelete(null);
        setShowAlert(false);
    }

    const handleChangeStatus = (item: any, newStatus: Boolean) => {
        console.log("Status to " + newStatus);
    };

    const getData = async () => {
        console.log("Fetching data...");
        try {
            const data = await fetchClient({ruta: "/racks/", metodo: "GET"});
            console.log(data);
            setData(data as any[]);
        } catch (error) {
            console.error("Error fetching data", error);
        }
    };

    const getWarehouseData = async () => {
        try {
            const data = await fetchClient({ruta: "/warehouses/", metodo: "GET"});
            setWarehouseData(data as any[]);
        } catch (error) {
            console.error("Error fetching data", error);
        }
    }

    useEffect(() => {
        const llamarLaData = async () => {
            await getData();
            await getWarehouseData();
        };
        llamarLaData();
    }, []);

    return (
        <div className='h-full w-full'>
            {dataTable ? <DynamicTable
                columns={columns}
                data={dataTable}
                paginationOptions={paginationOptions}
                tabs={tabs}
                title="Racks"
                subtitle="Gestión de racks"
                onEdit={(data) => {
                    setIsEdit(true);
                    setEditData({...data});
                }}
                onAdd={() => setIsCreate(true)}
                onDelete={(uid) => handleDelete(uid)}
                onStatusChange={handleChangeStatus}
            /> : <div>No Hay data mi brou</div>}

            {isCreate && <CreateModal
                title="Crear Rack"
                inputs={rackInputsCreate}
                onClose={() => setIsCreate(false)}
                onSave={(data) => handleAdd(data)}
            />}

            {isEdit && editData && <CreateModal
                title="Editar Rack"
                inputs={rackInputsEdit}
                onClose={() => setIsEdit(false)}
                onSave={(data) => handleEdit(data as any)}
            />}

            {showAlert && (
                <AlertComponent
                    title="Confirm Deletion"
                    description={`Are you sure you want to delete "${rackToDelete?.rackNumber}"? This action cannot be undone.`}
                    type="warning"
                    onAccept={confirmDelete}
                    onCancel={cancelDelete}
                />
            )}
        </div>
    );
}