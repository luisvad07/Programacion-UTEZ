'use client'

import { fetchClient } from "@/lib/utils/fetchClient";
import CreateModal from '@/components/common/CreateModal';
import { DynamicTable, TableColumn } from '@/components/layout/admin/DynamicTable';
import moment from 'moment';
import React, { useEffect, useState } from 'react';
import AlertComponent from "@/components/common/AlertComponent";


// Columnas de la tabla





// Configuración de paginación
const paginationOptions = {
    pageSize: 2,
    initialPage: 1,
};

// Tabs de ejemplo
const tabs = [
    { label: "Todos", value: "all" },
    { label: "Activo", value: "active" },
    { label: "Inactivo", value: "inactive" },
];





export default function UserPage() {
    const [isEdit, setIsEdit] = useState(false);
    const [isCreate, setIsCreate] = useState(false);
    const [editData, setEditData] = useState<any | null>(null);
    const [dataTable, setData] = useState<any[]>([]);
    const [warehouseData, setWarehouseData] = useState<any[]>([]);
    const [showAlert, setShowAlert] = useState(false);
    const [userToDelete, setUserToDelete] = useState<any | null>(null);

    const RoleOptions = [
        { uid: "ADMIN", name: "Admin" },
        { uid: "WAREHOUSE_WORKER", name: "Warehouse Worker" },
        { uid: "SUPER_ADMIN", name: "SuperAdmin" },
        { uid: "CLIENT", name: "Client" },
    ];
    const columns: TableColumn<any>[] = [
        { key: "name", label: "Nombre", sortable: true },
        { key: "email", label: "Correo Electrónico", sortable: true },
        { key: "role", label: "Rol", sortable: true },
        { key: "warehouse", label: "Almacén", sortable: true, render: (value) => value.warehouse ? value.warehouse.name : "Sin almacén" },
        { key: "active", label: "Activo", sortable: false, width: "75px" },
        { key: "lastModified", label: "Última Modificación", sortable: true, render: (value) => moment(value).format("DD/MM/YYYY") },
        { key: "actions", label: "Acciones", width: "100px" }, // Columna para acciones como editar
    ];
    const userInputsCreate = [
        {
            name: "name",
            label: "Nombre",
            value: "",
            type: "text",
            onChange: (name: string, value: any) => {
                console.log(`Input ${name} changed to ${value}`);
            },
        },
        {
            name: "email",
            label: "Correo Electrónico",
            value: "",
            type: "email",
            onChange: (name: string, value: any) => {
                console.log(`Input ${name} changed to ${value}`);
            },
        },
        {
            name: "password",
            label: "Contraseña",
            value: "",
            type: "password",
            onChange: (name: string, value: any) => {
                console.log(`Input ${name} changed to ${value}`);
            },
        },
        {
            name: "role",
            label: "Rol",
            value: "",
            type: "select",
            valuesToSelect: RoleOptions,
            onChange: (name: string, value: any) => {
                console.log(`Input ${name} changed to ${value}`);
            },
        },
        {
            name: "warehouse",
            label: "Almacén",
            value: "",
            type: "select",
            valuesToSelect: warehouseData,
            onChange: (name: string, value: any) => {
                console.log(`Input ${name} changed to ${value}`);
            },
        }
    ];

    const userInputsEdit = [
        {
            name: "name",
            label: "Nombre",
            value: editData?.name,
            type: "text",
            onChange: (name: string, value: any) => {
                console.log(`Input ${name} changed to ${value}`);
            },
        },
        {
            name: "email",
            label: "Correo Electrónico",
            value: editData?.email,
            type: "email",
            onChange: (name: string, value: any) => {
                console.log(`Input ${name} changed to ${value}`);
            },
        },
        {
            name: "role",
            label: "Rol",
            value: { uid: editData?.role },
            type: "select",
            valuesToSelect: RoleOptions,
            onChange: (name: string, value: any) => {
                console.log(`Input ${name} changed to ${value}`);
            },
        },
        {
            name: "warehouse",
            label: "Almacén",
            value: editData?.warehouse,
            type: "select",
            valuesToSelect: warehouseData,
            onChange: (name: string, value: any) => {
                console.log(`Input ${name} changed to ${value}`);
            },
        }
    ];
    // Función para editar
    const handleEdit = async (data: any) => {
        const role = data.role.uid;
        data.role = role;
        data.uid = editData.uid;
        data.active = editData.active;

        try {
            const updatedItem = await fetchClient({ ruta: `/users/update`, metodo: "PUT", datos: data });
            if (updatedItem) {
                const newData = await fetchClient({ ruta: "/users/", metodo: "GET" });
                setData(newData as any[]);
                setIsEdit(false);
                setEditData(null);
            }
        } catch (error) {
            console.error("Error editing item", error);
        }
    };

    // Función para añadir
    const handleAdd = async (data: any) => {
        const role = data.role.uid;
        data.role = role;
        try {
            const newItem = await fetchClient({ ruta: "/users/create", metodo: "POST", datos: data });
            if (newItem) {
                setData((prevData) => [...prevData, newItem]);
                setIsCreate(false);
            }
        } catch (error) {
            console.error("Error adding new item", error);
        }
    };

    const handleDelete = async (itemToDelete) => {
        setUserToDelete(itemToDelete);
        setShowAlert(true);
    }

    const confirmDelete = async () => {
        if (userToDelete) {
            try {
                await fetchClient({ ruta: `/users/change-status/${userToDelete.uid}`, metodo: "DELETE" });
                setData((prevData) => prevData.filter(item => item.uid !== userToDelete.uid));
                setUserToDelete(null);
                setShowAlert(false);
            } catch (error) {
                console.error("Error deleting item", error);
            }
        }
    }

    const cancelDelete = () => {
        setUserToDelete(null);
        setShowAlert(false);
    }

    const handleChangeStatus = (item: any, newStatus: boolean) => {
        console.log("Status to " + newStatus);
    };

    const getData = async () => {
        console.log("Fetching data...");
        try {
            const data = await fetchClient({ ruta: "/users/get-all", metodo: "GET" });
            console.log(data);
            setData(data as any[]);
        } catch (error) {
            console.error("Error fetching data", error);
        }
    };

    const getWarehouseData = async () => {
        try {
            const data = await fetchClient({ ruta: "/warehouses/", metodo: "GET" });
            setWarehouseData(data as any[]);
        } catch (error) {
            console.error("Error fetching data", error);
        }
    }

    useEffect(() => {
        const llamarLaData = async () => {
            await getData();
            await getWarehouseData();
        };
        llamarLaData();
    }, []);

    return (
        <div className='h-full w-full'>
            {dataTable ? <DynamicTable
                columns={columns}
                data={dataTable}
                paginationOptions={{
                    pageSize: 7,
                    initialPage: 1
                }}
                tabs={tabs}
                title="Usuarios"
                subtitle="Gestión de usuarios"
                onEdit={(data) => {
                    setIsEdit(true);
                    setEditData({ ...data });
                }}
                onAdd={() => setIsCreate(true)}
                onDelete={(uid) => handleDelete(uid)}
                onStatusChange={handleChangeStatus}
            /> : <div>No Hay data mi brou</div>}

            {isCreate && <CreateModal
                title="Crear Usuario"
                inputs={userInputsCreate}
                onClose={() => setIsCreate(false)}
                onSave={(data) => handleAdd(data)}
            />}


            {isEdit && editData && <CreateModal
                title="Editar Usuario"
                inputs={userInputsEdit}
                onClose={() => setIsEdit(false)}
                onSave={(data) => handleEdit(data as any)}
            />}

            {showAlert && (
                <AlertComponent
                    title="Confirm Deletion"
                    description={`Are you sure you want to delete "${userToDelete?.name}"? This action cannot be undone.`}
                    type="warning"
                    onAccept={confirmDelete}
                    onCancel={cancelDelete}
                />
            )}
        </div>
    );
}