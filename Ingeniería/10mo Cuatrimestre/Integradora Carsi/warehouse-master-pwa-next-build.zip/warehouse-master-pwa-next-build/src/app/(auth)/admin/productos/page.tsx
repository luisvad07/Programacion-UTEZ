'use client';

import {useState, useEffect} from 'react';
import {DynamicTable, TableColumn} from '@/components/layout/admin/DynamicTable';
import {Chip} from '@material-tailwind/react';
import CreateModal from '@/components/common/CreateModal';
import AlertComponent from '@/components/common/AlertComponent';
import {Category, Product, Rack, Supplier} from '@/types/common';
import {fetchClient} from "@/lib/utils/fetchClient";
import moment from 'moment';
import {colors} from "@material-tailwind/react/types/generic";


const getProducts = async (): Promise<Product[]> => {
    return await fetchClient({ruta: '/products/', metodo: 'GET'});
};


const createProduct = async (product: Product): Promise<Product> => {
    return await fetchClient({ruta: '/products/', metodo: 'POST', datos: product});
};

const updateProduct = async (product: Product): Promise<Product> => {
    return await fetchClient({ruta: '/products/', metodo: 'PUT', datos: product});
};

const deleteProduct = async (id: string): Promise<void> => {
    await fetchClient({ruta: `/products/${id}`, metodo: 'DELETE'});
};

const getCategories = async (): Promise<Category[]> => {
    return await fetchClient({ruta: '/categories/active/true', metodo: 'GET'});
}

const getSuppliers = async (): Promise<Supplier[]> => {
    return await fetchClient({ruta: '/suppliers/active/true', metodo: 'GET'});
}

const getRacks = async (): Promise<Rack[]> => {
    return await fetchClient({ruta: '/racks/active/true', metodo: 'GET'});
}

const getExpirationColor = (expirationDate: string): colors => {
    const now = moment();
    const expiration = moment(expirationDate);
    const diffDays = expiration.diff(now, 'days');

    if (diffDays <= 10) {
        return 'red';
    } else if (diffDays <= 60) {
        return 'yellow';
    } else {
        return 'green';
    }
};

const columns: TableColumn<any>[] = [
    {key: 'name', label: 'Nombre', sortable: true},
    {key: 'description', label: 'Descripción', sortable: true},
    {key: 'price', label: 'Precio ($)', sortable: true},
    {key: 'stock', label: 'Inventario', sortable: true},
    {key: 'supplier', label: 'Proveedor', sortable: true, render: (item) => item.supplier.name},
    {key: 'category', label: 'Categoría', sortable: true, render: (item) => item.category.name},
    {key: 'rack', label: 'Rack', sortable: true, render: (item) => item.rack.rackNumber},
    {key: 'warehouse', label: 'Almacén', sortable: true, render: (item) => item.rack.warehouse.name},
    {key: 'floorNumber', label: 'Número de Piso', sortable: true},
    {
        key: 'expirationDate',
        label: 'Fecha de Expiración',
        sortable: true,
        render: (item) => {
            const color = getExpirationColor(item.expirationDate);
            return (
                <Chip size="sm" variant="gradient" color={color} value={moment(item.expirationDate).format('DD/MM/YYYY')} />
            );
        }
    },
    {
        key: 'qrCode',
        label: 'Código QR',
        sortable: false,
        render: (item) => (
            item.qrCode ? <img src={item.qrCode} alt="Código QR" className="w-16 h-16"/> : 'Sin Código QR'
        )
    },
    {
        key: 'active', label: 'Activo', sortable: false, width: '75px', render: (item) => (
            <Chip size="sm" variant="gradient" color={item.active ? 'green' : 'red'}
                  value={item.active ? 'Activo' : 'Inactivo'}/>
        )
    },
    {
        key: 'lastModified',
        label: 'Última Modificación',
        sortable: true,
        render: (item) => moment(item.lastModified).format('DD/MM/YYYY')
    },
    {
        key: 'actions', label: 'Acciones', width: '100px', render: (item) => (
            <div className="flex space-x-2">
                <button className="text-yellow-500 hover:text-yellow-600">Editar
                </button>
                <button onClick={(e) => {
                    e.stopPropagation();
                    console.log(item);
                }} className="text-red-500 hover:text-red-600">Eliminar
                </button>
            </div>
        )
    }
];


const ProductPage = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [categories, setCategories] = useState<Category[]>([]);
    const [suppliers, setSuppliers] = useState<Supplier[]>([]);
    const [racks, setRacks] = useState<Rack[]>([]);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editProduct, setEditProduct] = useState<Product | null>(null);
    const [showAlert, setShowAlert] = useState(false);
    const [productToDelete, setProductToDelete] = useState<Product | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            const data = await getProducts();
            setProducts(data);
            const categoriesData = await getCategories();
            setCategories(categoriesData);
            const suppliersData = await getSuppliers();
            setSuppliers(suppliersData);
            const racksData = await getRacks();
            setRacks(racksData);
        };
        fetchData();
    }, []);

    const handleAddProduct = () => {
        setEditProduct(null);
        setIsModalOpen(true);
    };

    const handleEditProduct = (product: Product) => {
        setEditProduct(product);
        setIsModalOpen(true);
    };

    const handleDeleteProduct = (product: Product) => {
        setProductToDelete(product);
        setShowAlert(true);
    };

    const handleSaveProduct = async (data: Record<string, any>) => {
        const newProduct: Product = {
            ...editProduct,
            ...data,
            price: parseFloat(data.price),
            stock: parseInt(data.stock),
            active: true,
            lastModified: new Date().toISOString(),
        };
        newProduct.qrCode = null;
        if (editProduct) {
            await updateProduct(newProduct);
            const updatedProducts = await getProducts();
            setProducts(updatedProducts);
        } else {
            await createProduct(newProduct);
            const updatedProducts = await getProducts();
            setProducts(updatedProducts);
        }
        setIsModalOpen(false);
    };

    const confirmDeleteProduct = async () => {
        if (productToDelete) {
            await deleteProduct(productToDelete.uid);
            const updatedProducts = await getProducts();
            setProducts(updatedProducts);
            setShowAlert(false);
            setProductToDelete(null);
        }
    };

    const cancelDeleteProduct = () => {
        setShowAlert(false);
        setProductToDelete(null);
    };

    const tabs = [
        { label: "Todos", value: "all" },
        { label: "Activo", value: "active" },
        { label: "Inactivo", value: "inactive" },
    ];

    return (
        <div className="h-full w-full">
            <DynamicTable
                columns={columns}
                data={products}
                paginationOptions={{pageSize: 7, initialPage: 1}}
                title="Productos"
                tabs={tabs}
                subtitle="Gestión de productos"
                onAdd={handleAddProduct}
                onEdit={handleEditProduct}
                onDelete={handleDeleteProduct}
                onStatusChange={(item, newStatus: boolean) => {
                    const updatedProducts = products.map((product) =>
                        product.uid === item.uid ? {...product, active: newStatus} : product
                    );
                    setProducts(updatedProducts);
                }}
            />

            {isModalOpen && (
                <CreateModal
                    title={editProduct ? 'Edit Product' : 'Add Product'}
                    inputs={[
                        {
                            label: 'Nombre',
                            name: 'name', value: editProduct?.name || '', type: 'text', onChange: (name, value) => {
                            }
                        },
                        {
                            label: 'Descripción',
                            name: 'description',
                            value: editProduct?.description || '',
                            type: 'text',
                            onChange: (name, value) => {
                            }
                        },
                        {
                            label: 'Precio ($)',
                            name: 'price', value: editProduct?.price || '', type: 'number', onChange: (name, value) => {
                            }
                        },
                        {
                            label: 'Inventario',
                            name: 'stock', value: editProduct?.stock || '', type: 'number', onChange: (name, value) => {
                            }
                        },
                        {
                            label: 'Proveedor',
                            name: 'supplier',
                            value: editProduct ? {uid: editProduct.supplier.uid, name: editProduct.supplier.name} : {},
                            type: 'select',
                            valuesToSelect: suppliers.map((supplier) => {
                                return {uid: supplier.uid, name: supplier.name};
                            }),
                            onChange: (name, value) => {
                            }
                        },
                        {
                            label: 'Categoría',
                            name: 'category',
                            value: editProduct ? {uid: editProduct.category.uid, name: editProduct.category.name} : {},
                            type: 'select',
                            valuesToSelect: categories.map((category) => {
                                    return {uid: category.uid, name: category.name};
                                }
                            ),
                            onChange: (name, value) => {
                            }
                        },
                        {
                            label: 'Rack',
                            name: 'rack',
                            value: editProduct ? {uid: editProduct.rack.uid, name: editProduct.rack.rackNumber} : {},
                            type: 'select',
                            valuesToSelect: racks.map((rack) => {
                                    return {uid: rack.uid, name: rack.rackNumber};
                                }
                            ),
                            onChange: (name, value) => {
                            }
                        },
                        {
                            label: 'Número de Piso',
                            name: 'floorNumber',
                            value: editProduct?.floorNumber || '',
                            type: 'number',
                            onChange: (name, value) => {
                            }
                        },
                        {
                            label: 'Fecha de Expiración',
                            name: 'expirationDate',
                            value: editProduct ? moment(editProduct.expirationDate).format('YYYY-MM-DD') : '',
                            type: 'date',
                            onChange: (name, value) => {
                            }
                        },
                    ]}
                    onSave={handleSaveProduct}
                    onClose={() => setIsModalOpen(false)}
                />
            )}

            {showAlert && (
                <AlertComponent
                    title="Confirm Deletion"
                    description={`Are you sure you want to delete "${productToDelete?.name}"? This action cannot be undone.`}
                    type="warning"
                    onAccept={confirmDeleteProduct}
                    onCancel={cancelDeleteProduct}
                />
            )}
        </div>
    );
};

export default ProductPage;