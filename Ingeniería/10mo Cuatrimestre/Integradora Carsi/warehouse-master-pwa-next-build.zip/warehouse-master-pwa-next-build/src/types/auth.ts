export interface User {
    uid: string
    email: string
    role: string
    name: string
    active: boolean
    lastModified: string | null
    mfaEnabled: boolean | null
    password: string
    warehouse: object | null
}

export interface AuthResponse {
    data: {
        token: string
        user: User
    }
    message: string
    status: number
}