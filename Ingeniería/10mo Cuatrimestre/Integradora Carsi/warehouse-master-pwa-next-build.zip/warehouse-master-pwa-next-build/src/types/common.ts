export interface ApiResponse<T> {
    data?: T
    error?: string
    message?: string
  }

export interface Supplier {
    uid: string;
    name: string;
    contact: string;
    active: boolean;
    lastModified: string;
}

export interface Category {
    uid: string;
    name: string;
    description: string;
    active: boolean;
    lastModified: string;
}

export interface Warehouse {
    uid: string;
    name: string;
    location: string;
    capacity: number;
    active: boolean;
    lastModified: string;
}

export interface Rack {
    uid: string;
    warehouse: Warehouse | null;
    rackNumber: string;
    capacity: number;
    description: string;
    maxFloor: number;
    active: boolean;
    lastModified: string;
}

export interface Product {
    uid: string;
    name: string;
    description: string;
    price: number;
    supplier: Supplier | null;
    category: Category | null;
    rack: Rack | null;
    warehouse: Warehouse | null;
    floorNumber: number;
    stock: number;
    qrCode: string;
    expirationDate: string;
    active: boolean;
    lastModified: string;
}



export interface MfaDevice {
  uid: string;
  secretKey: string;
  user: User;
}

export interface User {
  uid: string;
  name: string;
  email: string;
  password: string;
  lastModified: string;
  role: string;
  warehouse: Warehouse | null;
  active: boolean;
  mfaEnabled: boolean;
  mfaDevice: MfaDevice | null;
}

export interface Movement {
    uid: string;
    product: Product | null;
    sourceWarehouse: Warehouse | null;
    destinationWarehouse: Warehouse | null;
    sourceRack: Rack | null;
    destinationRack: Rack | null;
    quantity: number;
    user: User | null;
    photo: string;
    observations: string;
    status: string;
    active: boolean;
    lastModified: string;
    assignedUser: User | null;
}

// Add the Status enum
export enum Status {
    UNASSIGNED_ENTRY,
    UNASSIGNED_EXIT,
    UNASSIGNED_TRANSFER,
    UNASSIGNED_ADJUSTMENT,
    ASSIGNED_ENTRY,
    ASSIGNED_EXIT,
    ASSIGNED_TRANSFER,
    ASSIGNED_ADJUSTMENT,
    PENDING_ENTRY,
    PENDING_EXIT,
    PENDING_TRANSFER,
    PENDING_ADJUSTMENT,
    ENTRY,
    EXIT,
    TRANSFER,
    ADJUSTMENT,
    CANCELLED
}