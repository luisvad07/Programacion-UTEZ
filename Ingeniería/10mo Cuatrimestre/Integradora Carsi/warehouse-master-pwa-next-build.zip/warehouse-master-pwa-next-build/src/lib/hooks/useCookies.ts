import Cookies from 'js-cookie';

const useCookie = () => {
    const getCookie = (key: string) => Cookies.get(key);

    const setCookie = (key: string, value: string) =>
        Cookies.set(key, value, {
            expires: 2, // 2 days
            sameSite: 'None',
            secure: true,
        });

    const removeCookie = (key: string) => Cookies.remove(key);

    return { setCookie, getCookie, removeCookie };
};

export default useCookie;