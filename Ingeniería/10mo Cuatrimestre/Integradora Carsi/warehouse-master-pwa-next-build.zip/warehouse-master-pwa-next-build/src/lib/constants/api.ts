export const API_URL = "http://129.213.69.201:8081/warehouse-master-api";
// export const API_URL = process.env.NEXT_PUBLIC_API_URL