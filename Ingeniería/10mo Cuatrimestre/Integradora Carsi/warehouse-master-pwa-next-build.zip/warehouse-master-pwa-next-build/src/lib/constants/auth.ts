export const AUTH_TOKEN_KEY = 'auth_token'
export const PUBLIC_ROUTES = ['/login', '/register', '/forgot-password']