import { API_URL } from "@/lib/constants/api";

export async function getUserData(): Promise<string | null> {
    try {
        if (typeof window !== "undefined") {
            const authToken = localStorage.getItem("auth_token");
            return authToken;
        }
        return null;
    } catch (error) {
        console.log(error);
        return null;
    }
}

interface FetchClientParams {
    ruta: string;
    metodo: string;
    datos?: any;
}

export async function fetchClient({ ruta, metodo, datos }: FetchClientParams): Promise<any> {
    try {
        const token = await getUserData();
        const url = `${API_URL}${ruta}`;
        const params: RequestInit = {
            method: metodo,
            headers: {
                "Content-Type": "application/json",
                ...(token && { Authorization: `Bearer ${token}` }),
            },
            body: datos ? JSON.stringify(datos) : null,
        };

        const response = await fetch(url, params);
        if (response.status >= 200 && response.status < 300) {
            const result = await response.json();
            return result.data;
        } else if (response.status === 401) {
            if (typeof window !== "undefined") {
                localStorage.removeItem("auth_token");
            }
            return null;
        }
    } catch (error) {
        console.log(error);
        return null;
    }
}