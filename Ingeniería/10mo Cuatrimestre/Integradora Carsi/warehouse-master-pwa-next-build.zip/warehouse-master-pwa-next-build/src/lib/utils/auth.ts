'use client'
import { AUTH_TOKEN_KEY } from '../constants/auth'
import type { User } from '@/types/auth'

export const getToken = (): string | null => {
  return localStorage.getItem(AUTH_TOKEN_KEY)
}

export const getUserData = (): User | null => {
    const user = localStorage.getItem('user')
    if (!user) return null
    return JSON.parse(user)
}

export const setToken = (token: string): void => {
    localStorage.setItem(AUTH_TOKEN_KEY, token)
}

export const removeToken = (): void => {
  localStorage.removeItem(AUTH_TOKEN_KEY)
  localStorage.removeItem('user')
}

export const parseJwt = <T = unknown>(token: string): T | null => {
  try {
    return JSON.parse(atob(token.split('.')[1])) as T;
  } catch (e) {
    console.error('Error parsing JWT', e);
    return null;
  }
};


export const validateToken = async (token: string): Promise<User | null> => {
  try {
    const response = await fetch('/api/auth/validate', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
    if (!response.ok) throw new Error('Token inválido')
    return response.json()
  } catch (error) {
    console.error('Error validating token', error);
    return null
  }
}

export const setUserData = (user: User): void => {
    localStorage.setItem('user', JSON.stringify(user))
}