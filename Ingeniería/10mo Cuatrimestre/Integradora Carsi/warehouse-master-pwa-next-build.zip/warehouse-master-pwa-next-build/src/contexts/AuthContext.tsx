'use client'
import {createContext, useContext, useEffect, useState} from 'react'
import {User, AuthResponse} from '@/types/auth'
import {getToken, setToken, removeToken, setUserData, getUserData} from '@/lib/utils/auth'
import {API_URL} from "@/lib/constants/api";
import useCookie from "@/lib/hooks/useCookies";
import {useRouter} from "next/navigation";



interface AuthContextType {
    user: User | null
    userNeedsMfa: boolean
    setUserNeedsMfa: (value: boolean) => void
    loading: boolean
    login: (email: string, password: string, mfaCode?: string) => Promise<void>
    logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({children}: { children: React.ReactNode }) {
    const [user, setUser] = useState<User | null>(null)
    const [loading, setLoading] = useState(true)
    const [userNeedsMfa, setUserNeedsMfa] = useState(false)
    const {getCookie, setCookie, removeCookie} = useCookie();
    const router = useRouter();

    useEffect(() => {
        const initializeAuth = async () => {
            const token = getToken()
            const user = getUserData()

            if (!token || !user || !tokenCookie || !userCookie) {
                setLoading(false)
                return
            }

            setUser(user)
            setToken(tokenCookie)
        }
        const tokenCookie = getCookie('token')
        const userCookie = getCookie('user')
        setLoading(false)
        console.log('initializeAuth')
        initializeAuth()
    }, [])

    const login = async (email: string, password: string, mfaCode?: string) => {
        try {
            const response = await fetch(mfaCode ? `${API_URL}/auth/verify-mfa` : `${API_URL}/auth/`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: mfaCode ? JSON.stringify({email, password, mfaCode}) : JSON.stringify({email, password})
            })

            if (!response.ok) throw new Error('Credenciales inválidas')

            const data: AuthResponse = await response.json()
            if(data.message === 'MFA required') {
                alert('MFA code is required')
                setUserNeedsMfa(true)
                return
            }

            router.push('/admin');
            setUserNeedsMfa(false)
            setToken(data.data.token)
            setUserData(data.data.user)
            setUser(data.data.user)
            setCookie('token', data.data.token)
            setCookie('user', JSON.stringify(data.data.user))

        } catch (error) {
            throw error
        }
    }


    const logout = () => {
        removeToken()
        setUser(null)
        removeCookie('token')
        removeCookie('user')
    }

    return (
        
        <AuthContext.Provider value={{user, loading, login, logout, userNeedsMfa, setUserNeedsMfa}}>
            {children}
        </AuthContext.Provider>
        
    )
}

export const useAuth = () => {
    const context = useContext(AuthContext)
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider')
    }
    return context
}