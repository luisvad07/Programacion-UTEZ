export default function AlertTag({ type }: { type: string }) {
    const mssages = {
        'success': {
            title: 'Exito',
            description: 'Acción relizada con exito.',
            background: 'bg-green-100',
            borderNfill: 'border-green-500',
            text: 'text-green-900'
        },
        'danger': {
            title: 'Error',
            description: 'Hubo un error al procesar su petición.',
            background: 'bg-red-100',
            borderNfill: 'border-red-500',
            text: 'text-red-900',
            text500: 'text-red-500'
        },
        default: {
            title: 'Información',
            description: 'Información importante.',
            background: 'bg-blue-100',
            borderNfill: 'border-blue-500',
            text: 'text-blue-900',
            text500: 'text-blue-500'
        }
    };

    const { title, description, background, borderNfill, text, text500 } = type ? mssages[type] : mssages.default;

    return (
        type === 'success' ? <div id="alertTagSuccess" className={`${background} absolute bottom-1 right-5 z-10 border-t-4 ${borderNfill} rounded-b ${text} px-4 py-3 shadow-md w-[20vw] animate-slide-in-right`} role={`alert`} style={{ display: "none" }}>
            <div className={`flex`}>
                <div className={`py-1`}><svg className={`fill-current h-6 w-6 ${text500} mr-4`} xmlns={`http://www.w3.org/2000/svg`} viewBox={`0 0 20 20`}><path d={`M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zm12.73-1.41A8 8 0 1 0 4.34 4.34a8 8 0 0 0 11.32 11.32zM9 11V9h2v6H9v-4zm0-6h2v2H9V5z`} /></svg></div>
                <div>
                    <p className={`font-bold`}>{title}</p>
                    <p className={`text-sm`}>{description}</p>
                </div>
            </div>
        </div> :
            <div id="alertTagDanger" className={`${background} absolute bottom-1 right-5 z-10 border-t-4 ${borderNfill} rounded-b ${text} px-4 py-3 shadow-md w-[20vw] animate-slide-in-right`} role={`alert`} style={{ display: "none" }}>
                <div className={`flex`}>
                    <div className={`py-1`}><svg className={`fill-current h-6 w-6 ${text500} mr-4`} xmlns={`http://www.w3.org/2000/svg`} viewBox={`0 0 20 20`}><path d={`M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zm12.73-1.41A8 8 0 1 0 4.34 4.34a8 8 0 0 0 11.32 11.32zM9 11V9h2v6H9v-4zm0-6h2v2H9V5z`} /></svg></div>
                    <div>
                        <p className={`font-bold`}>{title}</p>
                        <p className={`text-sm`}>{description}</p>
                    </div>
                </div>
            </div>
    );
}