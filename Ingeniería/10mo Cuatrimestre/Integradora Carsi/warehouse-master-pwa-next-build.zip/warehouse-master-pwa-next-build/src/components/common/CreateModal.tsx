import React, { useState } from 'react';

interface CreateModalProps {
  title: string;
  inputs: {
    name: string;
    label: string | null;
    value: string | boolean | File | object | number | null;
    type: string;
    valuesToSelect?: { uid: string, name: string }[];
    onChange: (name: string, value: string | boolean | File | object | number | null) => void;
  }[];
  onClose: () => void;
  onSave: (data: Record<string, string | boolean | File | object | number | null>) => void;
}

const CreateModal: React.FC<CreateModalProps> = ({ title, inputs, onClose, onSave }) => {
  const [formData, setFormData] = useState<Record<string, string | boolean | File | object | number | null>>(
    inputs.reduce((acc, input) => ({ ...acc, [input.name]: input.value }), {})
  );
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (name: string, value: string | boolean) => {
    setFormData({ ...formData, [name]: value });
  };

  const handleSelectChange = (name: string, uid: string) => {
    setFormData({ ...formData, [name]: { uid } });
  };

  const handleFileChange = (name: string, file: File | null) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, [name]: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    inputs.forEach((input) => {
      if (!formData[input.name]) {
        newErrors[input.name] = `${input.name} es requerido`;
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (validateForm()) {
      onSave(formData);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
        <h2 className="text-xl font-bold mb-4">{title}</h2>

        {inputs.map((input) => (
          <div key={input.name} className="mb-4">
            <label htmlFor={input.name} className="block text-sm font-medium text-gray-700">
              {input.label ? input.label : input.name}
            </label>
            {input.type === 'file' ? (
              <input
                type="file"
                name={input.name}
                onChange={(e) => handleFileChange(input.name, e.target.files ? e.target.files[0] : null)}
                className="mt-1 p-2 border rounded-md"
              />
            ) : input.type === 'select' ? (
              <select
                name={input.name}
                value={(formData[input.name] as { uid: string })?.uid || ''}
                onChange={(e) => handleSelectChange(input.name, e.target.value)}
                className="mt-1 p-2 border rounded-md w-full"
              >
                <option value="" disabled>Seleccione una opción</option>
                {input.valuesToSelect?.map((option) => (
                  <option key={option.uid} value={option.uid}>
                    {option.name}
                  </option>
                ))}
              </select>
            ) : (
              <input
                type={input.type}
                name={input.name}
                value={formData[input.name] as string}
                onChange={(e) => handleInputChange(input.name, e.target.value)}
                className="mt-1 p-2 border rounded-md w-full"
              />
            )}
            {errors[input.name] && <p className="text-red-500 text-sm mt-1">{errors[input.name]}</p>}
          </div>
        ))}

        <div className="flex justify-end space-x-4">
          <button
            onClick={onClose}
            className="bg-gray-300 hover:bg-gray-400 text-black py-2 px-4 rounded-lg"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            className="bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-lg"
          >
            Guardar
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreateModal;