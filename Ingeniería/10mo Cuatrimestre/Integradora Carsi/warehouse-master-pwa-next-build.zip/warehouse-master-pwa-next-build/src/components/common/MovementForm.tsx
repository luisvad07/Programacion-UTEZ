// Define the list of selectable statuses
const selectableStatuses = [
    "ENTRY",
    "EXIT",
    "TRANSFER",
    "ADJUSTMENT",
    "CANCELLED"
];

// Update MovementForm component
import React, { useState, useEffect } from 'react';
import { fetchClient } from "@/lib/utils/fetchClient";
import { Product, Rack, Warehouse } from '@/types/common';
import { User } from '@/types/auth';

interface MovementFormProps {
    initialData?: any;
    onSave: (data: any) => void;
    onClose: () => void;
}

const MovementForm: React.FC<MovementFormProps> = ({ initialData, onSave, onClose }) => {
    const [formData, setFormData] = useState<any>({
        products: initialData?.products || [{ product: '', quantity: '', destinationRack: null }],
        warehouse: initialData?.products?.[0]?.product?.warehouse || '',
        assignedUser: initialData?.assignedUser || '',
        photo: initialData?.photo || '',
        observations: initialData?.observations || '',
        status: initialData?.status || 'ENTRY',
    });
    const [productData, setProductData] = useState<Product[]>([]);
    const [warehouseData, setWarehouseData] = useState<Warehouse[]>([]);
    const [rackData, setRackData] = useState<Rack[]>([]);
    const [userData, setUserData] = useState<User[]>([]);
    const [errors, setErrors] = useState<Record<string, string>>({});

    useEffect(() => {
        const fetchData = async () => {
            const products = await fetchClient({ ruta: `/products/`, metodo: "GET" }) as any[];
            const warehouses = await fetchClient({ ruta: `/warehouses/`, metodo: "GET" }) as any[];
            const users = await fetchClient({ ruta: `/users/role/WAREHOUSE_WORKER`, metodo: "GET" }) as any[];
            setProductData(products || []);
            setWarehouseData(warehouses || []);
            setUserData(users || []);
        };
        fetchData();
    }, []);

    useEffect(() => {
        
    },[]);


    useEffect(() => {
        const fetchRacks = async () => {
            if (formData.warehouse) {
                const racks = await fetchClient({ ruta: `/racks/warehouse/${formData.warehouse}`, metodo: "GET" }) as any[];
                setRackData(racks || []);
            }
        };
        fetchRacks();
    }, [formData.warehouse]);

    const handleInputChange = (name: string, value: any) => {
        setFormData({ ...formData, [name]: value });
    };

    const handleProductChange = (index: number, name: string, value: any) => {
        const updatedProducts = [...formData.products];
        updatedProducts[index] = { ...updatedProducts[index], [name]: value };
        setFormData({ ...formData, products: updatedProducts });
    };

    const handleAddProduct = () => {
        setFormData({ ...formData, products: [...formData.products, { product: '', quantity: '', destinationRack: null }] });
    };

    const handleRemoveProduct = (index: number) => {
        const updatedProducts = formData.products.filter((_: any, i: number) => i !== index);
        setFormData({ ...formData, products: updatedProducts });
    };

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.products.length) newErrors.products = "Products are required";
        formData.products.forEach((product: any, index: number) => {
            if (!product.product) newErrors[`product_${index}`] = "Product is required";
            if (!product.quantity) newErrors[`quantity_${index}`] = "Quantity is required";
        });
        if (!formData.status) newErrors.status = "Status is required";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSave = () => {
        if (validateForm()) {
            onSave(formData);
            onClose();
        }
    };

    return (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
                <h2 className="text-xl font-bold mb-4">{initialData ? "Editar" : "Crear"} Movimiento</h2>

                {formData.products.map((product: any, index: number) => (
                    <div key={index} className="mb-4">
                        <label htmlFor={`product_${index}`} className="block text-sm font-medium text-gray-700">Producto</label>
                        <select
                            name={`product_${index}`}
                            value={product.product}
                            onChange={(e) => handleProductChange(index, 'product', { uid: e.target.value , name: e.target.options[e.target.selectedIndex].text })}
                            className="mt-1 p-2 border rounded-md w-full"
                        >
                            <option value="" disabled>Selecciona un producto</option>
                            {productData && productData.map((prod) => (
                                <option key={prod.uid} value={prod.uid}>{prod.name}</option>
                            ))}
                        </select>
                        {errors[`product_${index}`] && <p className="text-red-500 text-sm mt-1">{errors[`product_${index}`]}</p>}

                        <label htmlFor={`quantity_${index}`} className="block text-sm font-medium text-gray-700">Cantidad</label>
                        <input
                            type="number"
                            name={`quantity_${index}`}
                            value={product.quantity}
                            onChange={(e) => handleProductChange(index, 'quantity', e.target.value)}
                            className="mt-1 p-2 border rounded-md w-full"
                        />
                        {errors[`quantity_${index}`] && <p className="text-red-500 text-sm mt-1">{errors[`quantity_${index}`]}</p>}

                        {String(formData.status).includes('TRANSFER') && (
                            <>
                                <label htmlFor={`destinationRack_${index}`} className="block text-sm font-medium text-gray-700">Rack de Destino</label>
                                <select
                                    name={`destinationRack_${index}`}
                                    value={product.destinationRack}
                                    onChange={(e) => handleProductChange(index, 'destinationRack', { uid: e.target.value })}
                                    className="mt-1 p-2 border rounded-md w-full"
                                >
                                    <option value="" disabled>Selecciona un Rack de Destino</option>
                                    {rackData && rackData.map((rack) => (
                                        <option key={rack.uid} value={rack.uid}>{rack.rackNumber}</option>
                                    ))}
                                </select>
                                {errors[`destinationRack_${index}`] && <p className="text-red-500 text-sm mt-1">{errors[`destinationRack_${index}`]}</p>}
                            </>
                        )}

                        <button onClick={() => handleRemoveProduct(index)} className="bg-red-500 w-full hover:bg-red-600 text-white py-1 px-2 rounded-lg mt-2">Remover</button>
                    </div>
                ))}

                <button onClick={handleAddProduct} className="bg-blue-500 w-full hover:bg-blue-600 text-white py-2 px-4 rounded-lg mb-4">Agregar Producto</button>
                {String(formData.status).includes('TRANSFER') && (
                <div className="mb-4">
                    <label htmlFor="warehouse" className="block text-sm font-medium text-gray-700">Almacen</label>
                    <select
                        name="warehouse"
                        value={formData.warehouse}
                        onChange={(e) => handleInputChange("warehouse", e.target.value)}
                        className="mt-1 p-2 border rounded-md w-full"
                    >
                        <option value="" disabled>Select a warehouse</option>
                        {warehouseData && warehouseData.map((warehouse) => (
                            <option key={warehouse.uid} value={warehouse.uid}>{warehouse.name}</option>
                        ))}
                    </select>
                    {errors.warehouse && <p className="text-red-500 text-sm mt-1">{errors.warehouse}</p>}
                </div>
                )}

                <div className="mb-4">
                    <label htmlFor="assignedUser" className="block text-sm font-medium text-gray-700">Asignar Usuario</label>
                    <select
                        name="assignedUser"
                        value={formData.assignedUser}
                        onChange={(e) => handleInputChange("assignedUser", { uid: e.target.value , name: e.target.options[e.target.selectedIndex].text })}
                        className="mt-1 p-2 border rounded-md w-full"
                    >
                        <option value="" disabled>Selecciona un Usuario</option>
                        {userData && userData.map((user) => (
                            <option key={user.uid} value={user.uid}>{user.name}</option>
                        ))}
                    </select>
                </div>

                <div className="mb-4">
                    <label htmlFor="status" className="block text-sm font-medium text-gray-700">Estado</label>
                    {selectableStatuses.includes(formData.status) ? (
                        <select
                            name="status"
                            value={formData.status}
                            onChange={(e) => handleInputChange("status", e.target.value)}
                            className="mt-1 p-2 border rounded-md w-full"
                        >
                            {selectableStatuses.map((status) => (
                                <option key={status} value={status}>{status}</option>
                            ))}
                        </select>
                    ) : (
                        <input
                            type="text"
                            name="status"
                            value={formData.status}
                            readOnly
                            className="mt-1 p-2 border rounded-md w-full bg-gray-200"
                        />
                    )}
                    {errors.status && <p className="text-red-500 text-sm mt-1">{errors.status}</p>}
                </div>

                <div className="mb-4">
                    <label htmlFor="observations" className="block text-sm font-medium text-gray-700">Observaciones</label>
                    <textarea
                        name="observations"
                        value={formData.observations}
                        onChange={(e) => handleInputChange("observations", e.target.value)}
                        className="mt-1 p-2 border rounded-md w-full"
                    />
                </div>

                <div className="flex justify-end space-x-4">
                    <button
                        onClick={onClose}
                        className="bg-gray-300 hover:bg-gray-400 text-black py-2 px-4 rounded-lg"
                    >
                        Cancelar
                    </button>
                    <button
                        onClick={handleSave}
                        className="bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-lg"
                    >
                        Guardar
                    </button>
                </div>
            </div>
        </div>
    );
};

export default MovementForm;