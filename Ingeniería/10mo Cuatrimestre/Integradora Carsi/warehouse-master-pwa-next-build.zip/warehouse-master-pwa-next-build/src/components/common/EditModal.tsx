import React, { useState, useEffect } from 'react';

interface EditModalProps<T> {
  title: string;
  initialData: Record<string, T>;
  inputs: { name: string; type: string }[];
  onClose: () => void;
  onSave: (data: Record<string, T>) => void;
}

const EditModal = <T extends string | number | readonly string[],>({ title, initialData, inputs, onClose, onSave }: EditModalProps<T>) => {
  const [formData, setFormData] = useState<Record<string, T>>(initialData);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    setFormData(initialData); // Set initial data when modal opens
  }, [initialData]);

  const handleInputChange = (name: string, value: T) => {
    setFormData({ ...formData, [name]: value });
  };

  const handleFileChange = (name: string, file: File | null) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, [name]: reader.result } as Record<string, T>);
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    inputs.forEach((input) => {
      if (!formData[input.name] && input.type !== 'file') {
        newErrors[input.name] = `${input.name} es requerido`;
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (validateForm()) {
      onSave(formData);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
        <h2 className="text-xl font-bold mb-4">{title}</h2>

        {inputs.map((input) => (
          <div key={input.name} className="mb-4">
            <label htmlFor={input.name} className="block text-sm font-medium text-gray-700">
              {input.name}
            </label>
            {input.type === 'file' ? (
              <input
                type="file"
                name={input.name}
                onChange={(e) => handleFileChange(input.name, e.target.files ? e.target.files[0] : null)}
                className="mt-1 p-2 border rounded-md"
              />
            ) : (
              <input
                type={input.type}
                name={input.name}
                value={formData[input.name] || ''}
                onChange={(e) => handleInputChange(input.name, e.target.value as T)}
                className="mt-1 p-2 border rounded-md w-full"
              />
            )}
            {errors[input.name] && <p className="text-red-500 text-sm mt-1">{errors[input.name]}</p>}
          </div>
        ))}

        <div className="flex justify-end space-x-4">
          <button
            onClick={onClose}
            className="bg-gray-300 hover:bg-gray-400 text-black py-2 px-4 rounded-lg"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-lg"
          >
            Guardar
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditModal;
