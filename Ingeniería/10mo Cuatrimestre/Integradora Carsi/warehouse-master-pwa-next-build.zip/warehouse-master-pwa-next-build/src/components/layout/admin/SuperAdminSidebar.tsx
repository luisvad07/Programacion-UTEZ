"use client";
import { HomeIcon } from "@heroicons/react/24/solid";
import {
    FaBox,
    FaWarehouse,
    FaTruck,
    FaExchangeAlt,
    FaUsers,
    FaTypo3,
    FaServer
} from "react-icons/fa";
import { usePathname } from "next/navigation";
import Link from "next/link";

export function SuperAdminSidebar() {
    const pathname = usePathname();

    const menuItems = [
        {
            label: "Home",
            href: "/admin",
            icon: <HomeIcon className="w-5 h-5" />,
        },
        {
            label: "Productos",
            href: "/admin/productos",
            icon: <FaBox className="w-5 h-5" />,
        },
        {
            label: "Almacenes",
            href: "/admin/almacenes",
            icon: <FaWarehouse className="w-5 h-5" />,
        },
        {
            label: "Racks",
            href: "/admin/racks",
            icon: <FaServer className="w-5 h-5" />,
        },
        {
            label: "Proveedores",
            href: "/admin/proveedores",
            icon: <FaTruck className="w-5 h-5" />,
        },
        {
            label: "Movimientos",
            href: "/admin/movimientos",
            icon: <FaExchangeAlt className="w-5 h-5" />,
        },
        {
            label: "Usuarios",
            href: "/admin/users",
            icon: <FaUsers className="w-5 h-5" />,
        },
        {
            label: "Categorías",
            href: "/admin/categorias",
            icon: <FaTypo3 className="w-5 h-5" />,
        }
    ];

    return (
        <div className="relative flex h-100vh w-full max-w-[20rem] flex-col bg-[#4b0019cc] p-4 text-gray-100">

            <div className="p-4 mb-2">
                <h5 className="block font-sans text-xl antialiased font-semibold leading-snug tracking-normal text-100">
                    Super Admin
                </h5>
            </div>
            <nav className="flex min-w-[240px] flex-col gap-1 p-2 font-sans text-base font-normal text-blue-gray-50">
                {menuItems.map((item) => (
                    <Link key={item.href} href={item.href} legacyBehavior>
                        <a className={`flex items-center w-full p-3 leading-tight transition-all rounded-lg outline-none text-start ${pathname === item.href ? "bg-blue-gray-50 bg-opacity-80 text-deepMaroonOpacityOff" : "hover:bg-blue-gray-50 hover:bg-opacity-80 hover:text-deepMaroonOpacityOff focus:bg-blue-gray-50 focus:bg-opacity-80 focus:text-deepMaroonOpacityOff active:bg-blue-gray-50 active:bg-opacity-80 active:text-deepMaroonOpacityOff"}`}>
                            <div className="grid mr-4 place-items-center">
                                {item.icon}
                            </div>
                            {item.label}
                        </a>
                    </Link>
                ))}
            </nav>
        </div>
    );
}