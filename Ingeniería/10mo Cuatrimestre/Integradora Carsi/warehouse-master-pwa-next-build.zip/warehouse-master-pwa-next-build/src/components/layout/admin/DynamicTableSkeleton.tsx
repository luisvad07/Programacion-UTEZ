// src/components/layout/admin/SkeletonTable.tsx
import React from 'react';
import { Card, CardBody, CardFooter, CardHeader, Typography, Button } from "@/components/material/dinamicTable";

const SkeletonRow = () => (
  <tr className="animate-pulse">
    <td className="p-4">
      <div className="h-4 bg-gray-300 rounded w-20"></div>
    </td>
    <td className="p-4">
      <div className="h-4 bg-gray-300 rounded w-32"></div>
    </td>
    <td className="p-4">
      <div className="h-4 bg-gray-300 rounded w-24"></div>
    </td>
    <td className="p-4">
      <div className="h-4 bg-gray-300 rounded w-16"></div>
    </td>
  </tr>
);
const SkeletonHead = () => (
    <tr className="animate-pulse">
      <td className="p-4">
        <div className="h-4 bg-gray-700 rounded w-94"></div>
      </td>
      <td className="p-4">
        <div className="h-4 bg-gray-700 rounded w-94"></div>
      </td>
      <td className="p-4">
        <div className="h-4 bg-gray-700 rounded w-94"></div>
      </td>
      <td className="p-4">
        <div className="h-4 bg-gray-700 rounded w-94"></div>
      </td>
      
    </tr>
  );

const SkeletonTable = () => {
  return (
    <Card className="h-full w-full rounded-none px-3"  placeholder={undefined}>
      <CardHeader floated={false} shadow={false}  placeholder={undefined}>
        <div className="mb-8 flex items-center justify-between gap-8">
          <div>
            <Typography variant="h5" color="blue-gray"  placeholder={undefined}>
              Loading Data...
            </Typography>
            <Typography color="gray" className="mt-1 font-normal"  placeholder={undefined}>
              Please wait while we load the table data.
            </Typography>
          </div>
          <Button className="flex items-center gap-3" size="sm" disabled  placeholder={undefined}>
            <div className="h-4 w-4 bg-gray-300 rounded animate-pulse"></div> Add New
          </Button>
        </div>
      </CardHeader>

      <CardBody className="overflow-auto px-0"  placeholder={undefined}>
        <table className="mt-4 w-full min-w-max table-auto text-left">
          <thead className="animate-pulse">
            <SkeletonHead/>
          </thead>
          <tbody>
            {/* Skeleton rows */}
            {Array.from({ length: 5 }).map((_, index) => (
              <SkeletonRow key={index} />
            ))}
          </tbody>
        </table>
      </CardBody>

      <CardFooter className="flex items-center justify-between border-t border-blue-gray-50 p-4"  placeholder={undefined}>
        <Typography variant="small" color="blue-gray" className="font-normal"  placeholder={undefined}>
          Page loading...
        </Typography>
        <div className="flex gap-2">
          <Button variant="outlined" size="sm" disabled  placeholder={undefined}>
            Previous
          </Button>
          <Button variant="outlined" size="sm" disabled  placeholder={undefined}>
            Next
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default SkeletonTable;
