import {
    Popover,
    PopoverHandler,
    PopoverContent,
    List,
    ListItem,
    Chip, 
} from "@/components/material/statusPopOver";


interface PopoverStatusProps<T> {
    onStatusChange: (item: T, newStatus: Boolean) => void;
    status: Boolean;
    item: T
}

export default function StatusPopOver<T>({ status, onStatusChange, item }: PopoverStatusProps<T>) {
    return (
        <Popover placement="left-start">
            <PopoverHandler>
                {status ? <Chip className={`transform transition-transform duration-100 hover:scale-105 cursor-pointer grid justify-items-center font-bold bg-green-100 text-green-800`} value={'Activo'}>
                </Chip> :
                    <Chip className={`transform transition-transform duration-100 hover:scale-105 cursor-pointer grid justify-items-center font-bold bg-red-100 text-red-800`} value={'Inactivo'}>
                    </Chip>
                }
            </PopoverHandler>
            <PopoverContent className="p-0 w-28" placeholder={undefined} onPointerEnterCapture={() => {}} onPointerLeaveCapture={undefined}>
                {/* <div className="grid justify-items-center border-b border-blue-gray-50">
                    <div>
                        <Typography color="blue-gray" className="text-sm" placeholder={undefined} onPointerEnterCapture={() => {}} onPointerLeaveCapture={undefined}>
                            Cambiar Status
                        </Typography>
                    </div>
                </div> */}
                <List className="p-0 w-28 max-w-28 flex items-start justify-start" placeholder={undefined} onPointerEnterCapture={() => {}} onPointerLeaveCapture={undefined}>
                    {!status ? <a href="#" className="text-initial font-medium text-blue-gray-500" onClick={()=>{
                        onStatusChange(item, true);
                    }}>
                        <ListItem className="px-0 w-28 grid justify-items-center" placeholder={undefined} onPointerEnterCapture={() => {}} onPointerLeaveCapture={undefined}>
                            <Chip className={`font-bold bg-green-100 text-green-800`} value={'Activo'}>
                            </Chip>
                        </ListItem>
                    </a> : 
                    <a href="#" className="w-28 text-initial font-medium text-blue-gray-500" onClick={()=>{
                        onStatusChange(item, false);
                    }}>
                        <ListItem className="px-0 w-28 grid justify-items-center" placeholder={undefined} onPointerEnterCapture={() => {}} onPointerLeaveCapture={undefined}>
                            <Chip className={`font-bold bg-red-100 text-red-800`} value={'Inactivo'}>
                            </Chip>
                        </ListItem>
                    </a>}
                </List>
            </PopoverContent>
        </Popover>
    );
}