// src/components/layout/admin/DynamicTable.tsx
'use client';
import React, { useState, useCallback, useMemo } from 'react';
import {
    MagnifyingGlassIcon,
    ChevronUpDownIcon,
    TrashIcon,
    PencilSquareIcon,
} from "@heroicons/react/24/outline";
import { UserPlusIcon } from "@heroicons/react/24/solid";
import {
    Card,
    CardHeader,
    Input,
    Typography,
    Button,
    CardBody,
    CardFooter,
    Tabs,
    TabsHeader,
    Tab,
} from "@/components/material/dinamicTable";
import StatusPopOver from './StatusPopover';

export interface TableColumn<T> {
    key: keyof T | 'actions';
    label: string;
    sortable?: boolean;
    render?: (item: T) => React.ReactNode;
    width?: string;
}

interface PaginationInfo {
    pageSize: number;
    initialPage?: number;
}

interface TableProps<T> {
    columns: TableColumn<T>[];
    data: T[];
    paginationOptions: PaginationInfo;
    tabs?: Array<{ label: string; value: string }>;
    title?: string;
    subtitle?: string;
    onStatusChange: (item: T, newStatus: boolean) => void;
    onEdit?: (item: T) => void;
    onAdd?: () => void;
    onDelete?: (item: T) => void;
    isEnabledDelete?: boolean;
}

const statusConfigKeys = [
    'UNASSIGNED_EXIT',
    'ENTRY',
    'EXIT',
    'TRANSFER',
];

export function DynamicTable<T extends { uid: string; active: boolean; status: string | null }>({
    columns,
    data,
    paginationOptions,
    tabs,
    title = "Dynamic Table",
    subtitle = "Table subtitle",
    onStatusChange,
    onEdit,
    onAdd,
    onDelete, // Add onDelete prop
    isEnabledDelete = true,
}: TableProps<T>) {
    // Estado interno
    const [activeTab, setActiveTab] = useState(tabs?.[0]?.value || 'all');
    const [currentPage, setCurrentPage] = useState(paginationOptions.initialPage || 1);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortConfig, setSortConfig] = useState<{
        key: keyof T | null;
        direction: 'asc' | 'desc';
    }>({ key: null, direction: 'asc' });

    // Búsqueda
    // Búsqueda y filtrado por tab
    const filteredData = useMemo(() => {
        return data.filter((item) => {
            const searchStr = searchQuery.toLowerCase();

            // Filtra según el estado activo de la tab
            const matchesTab =
                activeTab === 'all' ||
                (activeTab === 'active' && item.active) ||
                (activeTab === 'inactive' && !item.active) ||
                statusConfigKeys.includes(activeTab) && item.status === activeTab;

            // Filtra según el término de búsqueda
            const matchesSearch = Object.values(item).some(
                (value) =>
                    value &&
                    typeof value === 'string' &&
                    value.toLowerCase().includes(searchStr)
            );

            return matchesTab && matchesSearch;
        });
    }, [data, searchQuery, activeTab]);


    // Ordenamiento
    const sortedData = useMemo(() => {
        if (!sortConfig.key) return filteredData;

        return [...filteredData].sort((a, b) => {
            if (a[sortConfig.key!] === b[sortConfig.key!]) return 0;

            const aValue = a[sortConfig.key!];
            const bValue = b[sortConfig.key!];

            if (typeof aValue === 'string' && typeof bValue === 'string') {
                return sortConfig.direction === 'asc'
                    ? aValue.localeCompare(bValue)
                    : bValue.localeCompare(aValue);
            }

            return sortConfig.direction === 'asc'
                ? aValue < bValue ? -1 : 1
                : bValue < aValue ? -1 : 1;
        });
    }, [filteredData, sortConfig]);

    // Paginación
    const paginatedData = useMemo(() => {
        const startIndex = (currentPage - 1) * paginationOptions.pageSize;
        const endIndex = startIndex + paginationOptions.pageSize;
        return sortedData.slice(startIndex, endIndex);
    }, [sortedData, currentPage, paginationOptions.pageSize]);

    const totalPages = Math.ceil(sortedData.length / paginationOptions.pageSize);

    // Manejadores
    const handleSearch = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        setSearchQuery(e.target.value);
        setCurrentPage(1); // Reset to first page on search
    }, []);

    const handleSort = useCallback((key: keyof T) => {
        setSortConfig(current => ({
            key,
            direction: current.key === key && current.direction === 'asc' ? 'desc' : 'asc'
        }));
    }, []);

    const handlePageChange = useCallback((newPage: number) => {
        setCurrentPage(newPage);
    }, []);

    const renderCell = (item: T, column: TableColumn<T>) => {
        if (column.key === 'actions') {
            return (
                <div className='flex flex-row gap-1 items-center cursor-pointer'>
                    <div
                        className='bg-white hover:bg-gray-200 transition-colors duration-300 hover:text-blue-gray-900 text-blue-gray-900 rounded w-full px-5 py-2'
                        onClick={() => {
                            onEdit({ ...item });
                        }}>
                        <PencilSquareIcon width={15} />
                    </div>
                    {isEnabledDelete && (
                        <div
                            className='bg-white hover:bg-gray-200 transition-colors duration-300 text-blue-gray-900 rounded w-full px-5 py-2'
                            onClick={() => {
                                try {
                                    onDelete?.(item); // Add delete button
                                } catch (error) {
                                    console.error(error);
                                }
                            }}>
                            {item.active ? (
                                <TrashIcon width={15} />
                            ) : (
                                <UserPlusIcon />
                            )}
                        </div>
                    )}
                </div>
            );
        }
        if (column.key === 'active') {
            return (
                <StatusPopOver status={item.active} item={item} onStatusChange={onStatusChange} />
            );
        }

        if (column.render) {
            return column.render(item);
        }


        if (item && item[column.key] && String(item[column.key]).length > 40) {
            return String(item[column.key]).slice(0, 40) + '...';
        }

        return String(item[column.key]);
    };

    return (<div className='h-full w-full'>
        <Card className="h-full w-full rounded-none px-3" placeholder={undefined}>
            <CardHeader floated={false} shadow={false} className="" placeholder={undefined}>
                <div className="mb-8 flex items-center justify-between gap-8">
                    <div>
                        <Typography variant="h5" color="blue-gray" placeholder={undefined}>
                            {title}
                        </Typography>
                        <Typography color="gray" className="mt-1 font-normal" placeholder={undefined}>
                            {subtitle}
                        </Typography>
                    </div>
                    {onAdd && (
                        <Button
                            className="flex items-center gap-3 bg-deepMaroonOpacityOff"
                            size="sm"
                            onClick={onAdd}
                            placeholder={undefined}
                            onPointerEnterCapture={() => {
                            }}
                            onPointerLeaveCapture={undefined}
                        >
                            <UserPlusIcon strokeWidth={2} className="h-4 w-4" /> Crear uno nuevo
                        </Button>
                    )}
                </div>

                <div className="flex flex-col items-center justify-between gap-1 md:flex-row">
                    {tabs && (
                        <Tabs value={activeTab} className="w-full md:w-max relative">

                            <TabsHeader placeholder={undefined} className='flex place-items-center'>
                                {tabs.map(({ label, value }) => (
                                    <Tab
                                        className='w-16 h-10'
                                        key={value}
                                        activeClassName='parentTab text-gray-100'
                                        value={value}
                                        onClick={() => {
                                            setActiveTab(value);
                                            setCurrentPage(1);
                                        }}
                                        placeholder={undefined}
                                        onPointerEnterCapture={() => {
                                        }}
                                        onPointerLeaveCapture={undefined}
                                    >
                                        {label}
                                    </Tab>
                                ))}
                            </TabsHeader>
                        </Tabs>
                    )}
                    <div className="w-full md:w-72">
                        <Input
                            label="Buscar ..."
                            icon={<MagnifyingGlassIcon className="h-5 w-5" />}
                            value={searchQuery}
                            onChange={handleSearch}
                            onPointerEnterCapture={() => {
                            }}
                            onPointerLeaveCapture={undefined}
                            crossOrigin={undefined}
                        />
                    </div>
                </div>
            </CardHeader>

            <CardBody className="overflow-auto px-0" placeholder={undefined}>
                <table className="mt-4 w-full min-w-max table-auto text-left">
                    <thead>
                        <tr>
                            {columns.map((column) => (
                                <th
                                    key={String(column.key)}
                                    className={`cursor-pointer border-y border-blue-gray-100 bg-blue-gray-50/50 p-4 transition-colors hover:bg-blue-gray-50 ${column.sortable ? 'cursor-pointer' : ''
                                        }`}
                                    onClick={() =>
                                        column.sortable && handleSort(column.key as keyof T)
                                    }
                                >
                                    <Typography
                                        variant="small"
                                        color="blue-gray"
                                        style={{ width: column.width }}
                                        className="flex items-center justify-between gap-2 font-normal leading-none opacity-70"
                                        placeholder={undefined}
                                        onPointerEnterCapture={() => {
                                        }}
                                        onPointerLeaveCapture={undefined}
                                    >
                                        {column.label}
                                        {column.sortable && (
                                            <ChevronUpDownIcon
                                                strokeWidth={2}
                                                className={`h-4 w-4 ${sortConfig.key === column.key
                                                    ? 'text-blue-500'
                                                    : ''
                                                    }`}
                                            />
                                        )}
                                    </Typography>
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {paginatedData.map((item, index) => (
                            <tr key={item.uid}>
                                {columns.map((column) => (
                                    <td
                                        key={`${item.uid}-${String(column.key)}`}
                                        style={{ width: column.width }}
                                        className={`p-4 ${index !== paginatedData.length - 1
                                            ? 'border-b border-blue-gray-50'
                                            : ''
                                            }`}
                                    >
                                        {renderCell(item, column)}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </CardBody>

            <CardFooter
                className="flex items-center justify-between border-t border-blue-gray-50 p-4"
                placeholder={undefined}
                onPointerEnterCapture={() => {
                }}
                onPointerLeaveCapture={undefined}
            >
                <Typography
                    variant="small"
                    color="blue-gray"
                    className="font-normal"
                    placeholder={undefined}
                    onPointerEnterCapture={() => {
                    }}
                    onPointerLeaveCapture={undefined}
                >
                    Pagina {currentPage} de {totalPages}
                </Typography>
                <div className="flex gap-2">
                    <Button
                        variant="outlined"
                        size="sm"
                        disabled={currentPage === 1}
                        onClick={() => handlePageChange(currentPage - 1)}
                        placeholder={undefined}
                        onPointerEnterCapture={() => {
                        }}
                        onPointerLeaveCapture={undefined}
                    >
                        Anterior
                    </Button>
                    <Button
                        variant="outlined"
                        size="sm"
                        disabled={currentPage === totalPages}
                        onClick={() => handlePageChange(currentPage + 1)}
                        placeholder={undefined}
                        onPointerEnterCapture={() => {
                        }}
                        onPointerLeaveCapture={undefined}
                    >
                        Siguiente
                    </Button>
                </div>
            </CardFooter>
        </Card>

    </div>
    );
}