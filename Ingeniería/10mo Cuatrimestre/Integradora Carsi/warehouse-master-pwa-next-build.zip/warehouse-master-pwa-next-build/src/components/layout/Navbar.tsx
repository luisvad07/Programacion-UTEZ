'use client'
import { useAuth } from '@/contexts/AuthContext'
import {
  Navbar as MTNavbar,
  Typography,
  Avatar,
  MenuHandler,
  MenuList,
  MenuItem,
  Menu,
} from "@material-tailwind/react"
import { useRouter } from "next/navigation";

export function Navbar() {
  const { logout } = useAuth();

  const user = localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : null;
  const router = useRouter()

  const logoutAndRedirect = async () => {
    logout()
    router.push('/login')
  }
  return (
    <MTNavbar className="max-w-full px-4 py-2 h-[7vh] rounded-none bg-deepMaroon" style={{ border: "none" }} placeholder={undefined} onPointerEnterCapture={() => { }} onPointerLeaveCapture={undefined}>
      <div className="flex items-center justify-between text-gray-100">
        <Typography
          as="a"
          href="#"
          className="mr-4 cursor-pointer py-1.5 font-bold" placeholder={undefined} onPointerEnterCapture={() => { }} onPointerLeaveCapture={undefined}        >
          Warehouse Master
        </Typography>

        <div className="flex items-center gap-4">
          <div className="hidden lg:flex items-center gap-2">
            <Typography variant="small" color="white" placeholder={undefined} onPointerEnterCapture={() => { }} onPointerLeaveCapture={undefined}>
              {user?.email}
            </Typography>
          </div>
          <Menu>
            <MenuHandler>
              <Avatar
                variant="circular"
                size="sm"
                alt="user avatar"
                className="cursor-pointer"
                src="https://img.freepik.com/premium-vector/stylish-default-user-profile-photo-avatar-vector-illustration_664995-352.jpg" placeholder={undefined} onPointerEnterCapture={() => { }} onPointerLeaveCapture={undefined} />
            </MenuHandler>
            <MenuList placeholder={undefined} onPointerEnterCapture={() => { }} onPointerLeaveCapture={undefined}>
              <MenuItem className="flex items-center gap-2" placeholder={undefined} onPointerEnterCapture={() => { }} onPointerLeaveCapture={undefined}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={2}
                  stroke="currentColor"
                  className="h-4 w-4"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
                <Typography placeholder={"Mi perfil"} variant="small" className="font-normal" onClick={() => router.push('/admin/profile')}>
                  Mi Perfil
                </Typography>
              </MenuItem>
              <MenuItem className="flex items-center gap-2" onClick={logoutAndRedirect} placeholder={undefined} onPointerEnterCapture={undefined} onPointerLeaveCapture={undefined}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={2}
                  stroke="currentColor"
                  className="h-4 w-4"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M5.636 5.636a9 9 0 1012.728 0M12 3v9"
                  />
                </svg>
                <Typography variant="small" className="font-normal" placeholder={undefined} onPointerEnterCapture={() => { }} onPointerLeaveCapture={undefined}>
                  Cerrar Sesión
                </Typography>
              </MenuItem>
            </MenuList>
          </Menu>
        </div>
      </div>
    </MTNavbar>
  )
}