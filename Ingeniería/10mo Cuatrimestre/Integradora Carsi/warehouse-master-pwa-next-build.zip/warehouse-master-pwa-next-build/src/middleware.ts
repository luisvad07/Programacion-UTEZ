import {NextResponse} from 'next/server'
import type {NextRequest} from 'next/server'
import {PUBLIC_ROUTES} from './lib/constants/auth'

export async function middleware(request: NextRequest) {
    //const token = request.cookies.get('token')?.value

    // Verificar rutas públicas
    if (PUBLIC_ROUTES.some(route => request.nextUrl.pathname.startsWith(route))) {
        return NextResponse.next()
    }

    // if (!token) {
    //     return NextResponse.redirect(new URL('/login', request.url))
    // }

    try {
        // Aquí puedes agregar la verificación del token con tu backend
        return NextResponse.next()
    } catch (error) {
        console.error('Error verifying token', error);
        return NextResponse.redirect(new URL('/login', request.url))
    }
}

export const config = {
    matcher: ['/((?!api|_next/static|icon.svg).*)']
}